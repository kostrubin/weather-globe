# Changelog

## [0.0.20](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.19...v0.0.20) (2026-09-21)


### Bug Fixes

* rename the wasm build output to `om_file_format` ([#124](https://github.com/open-meteo/typescript-omfiles/issues/124)) ([ac9b95f](https://github.com/open-meteo/typescript-omfiles/commit/ac9b95f81c502573a1d9bb4c7df209526458cab5))

## [0.0.19](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.18...v0.0.19) (2026-09-17)

## [0.0.18](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.17...v0.0.18) (2026-08-25)

## [0.0.17](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.16...v0.0.17) (2026-06-02)

## [0.0.16](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.15...v0.0.16) (2026-05-12)


### Bug Fixes

* **deps:** bump upstream C code ([#74](https://github.com/open-meteo/typescript-omfiles/issues/74)) ([99c4fa5](https://github.com/open-meteo/typescript-omfiles/commit/99c4fa5b68245b03aeec4feb8f03df3ac1993a1a))

## [0.0.15](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.14...v0.0.15) (2026-02-12)


### Bug Fixes

* bump upstream for long string fix ([#68](https://github.com/open-meteo/typescript-omfiles/issues/68)) ([cb5dbf3](https://github.com/open-meteo/typescript-omfiles/commit/cb5dbf3e809f67093cfc16b7b4e5a717c36d13bc))

## [0.0.14](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.13...v0.0.14) (2026-02-03)

## [0.0.13](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.12...v0.0.13) (2025-10-31)

## [0.0.12](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.11...v0.0.12) (2025-10-14)

## [0.0.11](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.10...v0.0.11) (2025-08-30)

## [0.0.10](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.9...v0.0.10) (2025-08-28)


### Features

* add avx flag ([6189f7b](https://github.com/open-meteo/typescript-omfiles/commit/6189f7b3c3792baf9fcec42b5a2f4a9a5538d590))
* add option to disable etag validation ([#42](https://github.com/open-meteo/typescript-omfiles/issues/42)) ([fad805c](https://github.com/open-meteo/typescript-omfiles/commit/fad805cb5f6e122caab424296871c7e6cf9d80da))

## [0.0.9](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.8...v0.0.9) (2025-08-10)

## [0.0.8](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.7...v0.0.8) (2025-07-31)


### Bug Fixes

* improve build flags and minor fixes in decoder ([#36](https://github.com/open-meteo/typescript-omfiles/issues/36)) ([a60e50a](https://github.com/open-meteo/typescript-omfiles/commit/a60e50a89ed8cb08b9f4023af169f29fd6967f6d))

## [0.0.7](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.6...v0.0.7) (2025-07-30)


### Bug Fixes

* error during decoder init ([#35](https://github.com/open-meteo/typescript-omfiles/issues/35)) ([889c978](https://github.com/open-meteo/typescript-omfiles/commit/889c9786112da8566cbefa0107dd509c771ba159))

## [0.0.6](https://github.com/open-meteo/typescript-omfiles/compare/v0.0.5...v0.0.6) (2025-06-15)


### Features

* publish to npm via github actions ([#7](https://github.com/open-meteo/typescript-omfiles/issues/7)) ([7ef583d](https://github.com/open-meteo/typescript-omfiles/commit/7ef583d700908b9a9c91638c912e9fa454c6751b))


### Bug Fixes

* improve esm and cjs modules ([#11](https://github.com/open-meteo/typescript-omfiles/issues/11)) ([8e90da9](https://github.com/open-meteo/typescript-omfiles/commit/8e90da9f4d8dcc1ecc2ddd37c3ac24b8b286e501))
* Module warnings ([#25](https://github.com/open-meteo/typescript-omfiles/issues/25)) ([83ad124](https://github.com/open-meteo/typescript-omfiles/commit/83ad12446c83e24e6a86f580c463787d5cab3b33))
