import { FileSource } from "../types";
import { OmFileReaderBackend } from "./OmFileReaderBackend";

export class FileBackend implements OmFileReaderBackend {
  private fileObj: File | Blob | null = null;
  private memory: Uint8Array | null = null;
  private fileSize = 0;

  constructor(source: FileSource) {
    if (typeof File !== "undefined" && source instanceof File) {
      this.fileObj = source;
      this.fileSize = source.size;
    } else if (typeof Blob !== "undefined" && source instanceof Blob) {
      this.fileObj = source;
      this.fileSize = source.size;
    } else if (source instanceof ArrayBuffer) {
      this.memory = new Uint8Array(source);
      this.fileSize = this.memory.length;
    } else if (source instanceof Uint8Array) {
      this.memory = source;
      this.fileSize = source.length;
    } else {
      throw new Error("Unsupported file source type for browser FileBackend");
    }
  }

  async count(): Promise<number> {
    return Promise.resolve(this.fileSize);
  }

  async getBytes(offset: number, size: number): Promise<Uint8Array> {
    if (this.memory) {
      return this.memory.slice(offset, offset + size);
    }
    if (this.fileObj) {
      const blob = this.fileObj.slice(offset, offset + size);
      const buffer = await blob.arrayBuffer();
      return new Uint8Array(buffer);
    }
    throw new Error("No file or memory buffer available");
  }

  // No collectPrefetchTasks - prefetching has minor effect

  async close(): Promise<void> {
    // Nothing to clean up in browser
  }
}
