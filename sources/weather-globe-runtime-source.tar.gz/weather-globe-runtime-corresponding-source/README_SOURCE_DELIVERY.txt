Weather Globe runtime corresponding-source collection
Prepared2026-10-21; application source is supplied separately beside this collection.

This collection contains the exact22 installed npm production package snapshots,
original notices, readable publisher source-map text, complete pinned OM reader/WASM/C
source, and the remaining original runtime source forms obtained in the follow-up.
The package snapshots are copied by package name/version, not a node_modules tree.
There are no dependency caches, credentials, browser profiles or .git histories.

Preferred source mapping:
- Three.js: packages/three@0.186.1/src and required examples modules.
- TanStack Query/Core and Zod: original src directories in their package snapshots.
- React Use Measure: original src in its package snapshot.
- Lucide and its-fine: exact original source text recovered from publisher sourcesContent,
  with original maps preserved; see extracted-sourcemap-sources.
- buffer, base64-js and ieee754: original readable JavaScript in package snapshots.
- Type-only declarations: original .d.ts forms in package snapshots.
- OM reader/WASM: openmeteo-0.0.20-corresponding-source.tar.gz contains exact binding/
  reader commit659de288ac1e2d16f8e40ab0cb73f51a1e1e73f9 and populated exact C submodule
  18bee8578d953bd95ad7de1ae688faa7cf421f7c, licenses and Emscripten4.0.12 build instructions.
- React and ReactDOM19.3.1: complete original source commit61aa00df822d0eb76d0362eb8b6fdd3527693efe.
- Scheduler0.28.0, use-sync-external-store1.7.0 and reconciler0.34.0: complete source
  commit1d34f91dfde6bba84d08b683aaba164c7194dacb, verified by npm gitHead and package versions.
- Zustand5.0.15: source commit2115efb9e270e73ad1d3472dfe0e0c7b8c6abcd4, matched to npm provenance.
- suspend-react0.1.3: exact npm gitHead302d8cf52e0145385331ffc8bd822bff86bfd39a, original TypeScript
  and semantic-release scripts; source version placeholder is intentional.
- Babel runtime7.29.10: original helper TypeScript/generator/build scripts at release source
  7fb1b975177c66cc801082db380f701e1bca0eeb and attested build input1a34ef503d39ae8c7013aad8281594a0b524179a.
  Helper/generator source matches; only two package.json release metadata files differ.
- R3F9.8.2: r3f-9.8.2-preferred-source-reconstruction.tar.gz contains original TypeScript from
  d74622ea8ed717f7212d7e19d65ff3e325508389 plus two recorded package-metadata changes and a frozen
  successful build configuration. All13 installed JavaScript files match rebuilt normalized
  Babel ASTs; generated vendored reconciler JS matches byte-for-byte. See R3F archive REBUILD.txt,
  metadata patch, comparison script and source-build-ast-equivalence.json. The unavailable npm
  gitHead is NOT claimed retrieved; correspondence is instead supported by reconstruction.

Source archives retain LICENSE texts and original build/release scripts. Parent application
source includes the Vite scripts and frozen lockfile for installing/building Weather Globe.
Reconstruction does not claim every package or the entire application is byte-identically
reproducible. R3F comparison ignores only comments/positions/raw literal lexemes and generated
chunk filename hashes; syntax, identifiers and literal values match. Npm provenance payloads
and matching subject digests are saved; independent DSSE/Sigstore signature verification was
not performed. Compiler and bundler dependencies are identified by the included lockfiles.

Code/data licenses are separate. MIT/BSD/ISC source modules require their preserved notices;
they do not themselves impose upstream-source publication. This source collection supports
GPL2 corresponding-source delivery for a combined browser build. Deliver the matching
Weather Globe application source archive and this runtime collection beside the exact binary.
This audit supplies technical source-correspondence evidence, not a blanket legal guarantee.
