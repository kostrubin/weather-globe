import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'audio-lines-x',
  size: 24,
  node: [
    ['path', { d: 'M10 3v18', key: 'yhl04a' }],
    ['path', { d: 'M14 8v6.35', key: '1ubbml' }],
    ['path', { d: 'm17 17 5 5', key: 'p7ous7' }],
    ['path', { d: 'M18 5v8.1', key: '1icuhc' }],
    ['path', { d: 'M2 10v3', key: '1fnikh' }],
    ['path', { d: 'M22 10v3', key: '154ddg' }],
    ['path', { d: 'm22 17-5 5', key: 'gqnmv0' }],
    ['path', { d: 'M6 6v11', key: '11sgs0' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name AudioLinesX
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgM3YxOCIgLz4KICA8cGF0aCBkPSJNMTQgOHY2LjM1IiAvPgogIDxwYXRoIGQ9Im0xNyAxNyA1IDUiIC8+CiAgPHBhdGggZD0iTTE4IDV2OC4xIiAvPgogIDxwYXRoIGQ9Ik0yIDEwdjMiIC8+CiAgPHBhdGggZD0iTTIyIDEwdjMiIC8+CiAgPHBhdGggZD0ibTIyIDE3LTUgNSIgLz4KICA8cGF0aCBkPSJNNiA2djExIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/audio-lines-x
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const AudioLinesX = createLucideIcon(__iconData);

export default AudioLinesX;
