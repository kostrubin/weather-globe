import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'brick-wall-shield',
  size: 24,
  node: [
    ['path', { d: 'M12 9v1.258', key: 'iwpddn' }],
    ['path', { d: 'M16 3v5.46', key: 'd7ew98' }],
    [
      'path',
      { d: 'M21 9.118V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5.75', key: '137t5x' },
    ],
    [
      'path',
      {
        d: 'M22 17.5c0 2.499-1.75 3.749-3.83 4.474a.5.5 0 0 1-.335-.005c-2.085-.72-3.835-1.97-3.835-4.47V14a.5.5 0 0 1 .5-.499c1 0 2.25-.6 3.12-1.36a.6.6 0 0 1 .76-.001c.875.765 2.12 1.36 3.12 1.36a.5.5 0 0 1 .5.5z',
        key: '16j3tf',
      },
    ],
    ['path', { d: 'M3 15h7', key: '1qldh6' }],
    ['path', { d: 'M3 9h12.142', key: '1yjd6m' }],
    ['path', { d: 'M8 15v6', key: '1stoo3' }],
    ['path', { d: 'M8 3v6', key: 'vlvjmk' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BrickWallShield
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgOXYxLjI1OCIgLz4KICA8cGF0aCBkPSJNMTYgM3Y1LjQ2IiAvPgogIDxwYXRoIGQ9Ik0yMSA5LjExOFY1YTIgMiAwIDAgMC0yLTJINWEyIDIgMCAwIDAtMiAydjE0YTIgMiAwIDAgMCAyIDJoNS43NSIgLz4KICA8cGF0aCBkPSJNMjIgMTcuNWMwIDIuNDk5LTEuNzUgMy43NDktMy44MyA0LjQ3NGEuNS41IDAgMCAxLS4zMzUtLjAwNWMtMi4wODUtLjcyLTMuODM1LTEuOTctMy44MzUtNC40N1YxNGEuNS41IDAgMCAxIC41LS40OTljMSAwIDIuMjUtLjYgMy4xMi0xLjM2YS42LjYgMCAwIDEgLjc2LS4wMDFjLjg3NS43NjUgMi4xMiAxLjM2IDMuMTIgMS4zNmEuNS41IDAgMCAxIC41LjV6IiAvPgogIDxwYXRoIGQ9Ik0zIDE1aDciIC8+CiAgPHBhdGggZD0iTTMgOWgxMi4xNDIiIC8+CiAgPHBhdGggZD0iTTggMTV2NiIgLz4KICA8cGF0aCBkPSJNOCAzdjYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/brick-wall-shield
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BrickWallShield = createLucideIcon(__iconData);

export default BrickWallShield;
