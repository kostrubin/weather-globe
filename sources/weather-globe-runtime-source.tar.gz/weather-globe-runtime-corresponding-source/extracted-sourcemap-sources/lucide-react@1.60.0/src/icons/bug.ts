import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bug',
  size: 24,
  node: [
    ['path', { d: 'M12 20v-9', key: '1qisl0' }],
    ['path', { d: 'M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z', key: 'uouzyp' }],
    ['path', { d: 'M14.12 3.88 16 2', key: 'qol33r' }],
    ['path', { d: 'M21 21a4 4 0 0 0-3.81-4', key: '1b0z45' }],
    ['path', { d: 'M21 5a4 4 0 0 1-3.55 3.97', key: '5cxbf6' }],
    ['path', { d: 'M22 13h-4', key: '1jl80f' }],
    ['path', { d: 'M3 21a4 4 0 0 1 3.81-4', key: '1fjd4g' }],
    ['path', { d: 'M3 5a4 4 0 0 0 3.55 3.97', key: '1d7oge' }],
    ['path', { d: 'M6 13H2', key: '82j7cp' }],
    ['path', { d: 'm8 2 1.88 1.88', key: 'fmnt4t' }],
    ['path', { d: 'M9 7.13V6a3 3 0 1 1 6 0v1.13', key: '1vgav8' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Bug
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMjB2LTkiIC8+CiAgPHBhdGggZD0iTTE0IDdhNCA0IDAgMCAxIDQgNHYzYTYgNiAwIDAgMS0xMiAwdi0zYTQgNCAwIDAgMSA0LTR6IiAvPgogIDxwYXRoIGQ9Ik0xNC4xMiAzLjg4IDE2IDIiIC8+CiAgPHBhdGggZD0iTTIxIDIxYTQgNCAwIDAgMC0zLjgxLTQiIC8+CiAgPHBhdGggZD0iTTIxIDVhNCA0IDAgMCAxLTMuNTUgMy45NyIgLz4KICA8cGF0aCBkPSJNMjIgMTNoLTQiIC8+CiAgPHBhdGggZD0iTTMgMjFhNCA0IDAgMCAxIDMuODEtNCIgLz4KICA8cGF0aCBkPSJNMyA1YTQgNCAwIDAgMCAzLjU1IDMuOTciIC8+CiAgPHBhdGggZD0iTTYgMTNIMiIgLz4KICA8cGF0aCBkPSJtOCAyIDEuODggMS44OCIgLz4KICA8cGF0aCBkPSJNOSA3LjEzVjZhMyAzIDAgMSAxIDYgMHYxLjEzIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/bug
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Bug = createLucideIcon(__iconData);

export default Bug;
