import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'avocado',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M13.465 3.464a5 5 0 017.07 0 5 5 0 010 7.072c-1.204 1.203-2.38 2.89-2.614 4.577A8 8 0 118.886 6.08c1.687-.235 3.375-1.41 4.579-2.615',
        key: 'opbrel',
      },
    ],
    ['circle', { cx: '10', cy: '14', r: '3', key: '1l1kct' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Avocado
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTMuNDY1IDMuNDY0YTUgNSAwIDAxNy4wNyAwIDUgNSAwIDAxMCA3LjA3MmMtMS4yMDQgMS4yMDMtMi4zOCAyLjg5LTIuNjE0IDQuNTc3QTggOCAwIDExOC44ODYgNi4wOGMxLjY4Ny0uMjM1IDMuMzc1LTEuNDEgNC41NzktMi42MTUiIC8+CiAgPGNpcmNsZSBjeD0iMTAiIGN5PSIxNCIgcj0iMyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/avocado
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Avocado = createLucideIcon(__iconData);

export default Avocado;
