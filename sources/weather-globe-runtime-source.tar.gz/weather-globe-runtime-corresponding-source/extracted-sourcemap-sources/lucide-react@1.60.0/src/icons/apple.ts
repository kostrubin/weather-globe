import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'apple',
  size: 24,
  node: [
    ['path', { d: 'M12 6.528V3a1 1 0 0 1 1-1h0', key: '11qiee' }],
    [
      'path',
      {
        d: 'M18.237 21A15 15 0 0 0 22 11a6 6 0 0 0-10-4.472A6 6 0 0 0 2 11a15.1 15.1 0 0 0 3.763 10 3 3 0 0 0 3.648.648 5.5 5.5 0 0 1 5.178 0A3 3 0 0 0 18.237 21',
        key: '110c12',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Apple
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgNi41MjhWM2ExIDEgMCAwIDEgMS0xaDAiIC8+CiAgPHBhdGggZD0iTTE4LjIzNyAyMUExNSAxNSAwIDAgMCAyMiAxMWE2IDYgMCAwIDAtMTAtNC40NzJBNiA2IDAgMCAwIDIgMTFhMTUuMSAxNS4xIDAgMCAwIDMuNzYzIDEwIDMgMyAwIDAgMCAzLjY0OC42NDggNS41IDUuNSAwIDAgMSA1LjE3OCAwQTMgMyAwIDAgMCAxOC4yMzcgMjEiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/apple
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Apple = createLucideIcon(__iconData);

export default Apple;
