import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'castle',
  size: 24,
  node: [
    ['path', { d: 'M10 5V3', key: '1y54qe' }],
    ['path', { d: 'M14 5V3', key: 'm6isi' }],
    ['path', { d: 'M15 21v-3a3 3 0 0 0-6 0v3', key: 'lbp5hj' }],
    ['path', { d: 'M18 3v8', key: '2ollhf' }],
    ['path', { d: 'M18 5H6', key: '98imr9' }],
    ['path', { d: 'M22 11H2', key: '1lmjae' }],
    ['path', { d: 'M22 9v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9', key: '1rly83' }],
    ['path', { d: 'M6 3v8', key: 'csox7g' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Castle
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgNVYzIiAvPgogIDxwYXRoIGQ9Ik0xNCA1VjMiIC8+CiAgPHBhdGggZD0iTTE1IDIxdi0zYTMgMyAwIDAgMC02IDB2MyIgLz4KICA8cGF0aCBkPSJNMTggM3Y4IiAvPgogIDxwYXRoIGQ9Ik0xOCA1SDYiIC8+CiAgPHBhdGggZD0iTTIyIDExSDIiIC8+CiAgPHBhdGggZD0iTTIyIDl2MTBhMiAyIDAgMCAxLTIgMkg0YTIgMiAwIDAgMS0yLTJWOSIgLz4KICA8cGF0aCBkPSJNNiAzdjgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/castle
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Castle = createLucideIcon(__iconData);

export default Castle;
