import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'building-complex-plus',
  size: 24,
  node: [
    ['path', { d: 'M10 12h4', key: 'a56b0p' }],
    ['path', { d: 'M10 21v-3a2 2 0 013.05-1.702', key: 'm393w2' }],
    ['path', { d: 'M10 8h4', key: '1sr2af' }],
    ['path', { d: 'M16 19h6', key: 'xwg31i' }],
    ['path', { d: 'M18 7h2a2 2 0 012 2v4.355', key: 'p613ng' }],
    ['path', { d: 'M19 16v6', key: 'tddt3s' }],
    ['path', { d: 'M6 10H4a2 2 0 00-2 2v7a2 2 0 002 2h8.535', key: 's5wgjh' }],
    ['path', { d: 'M6 21V5a2 2 0 012-2h8a2 2 0 012 2v7.126', key: 'hmp3za' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BuildingComplexPlus
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgMTJoNCIgLz4KICA8cGF0aCBkPSJNMTAgMjF2LTNhMiAyIDAgMDEzLjA1LTEuNzAyIiAvPgogIDxwYXRoIGQ9Ik0xMCA4aDQiIC8+CiAgPHBhdGggZD0iTTE2IDE5aDYiIC8+CiAgPHBhdGggZD0iTTE4IDdoMmEyIDIgMCAwMTIgMnY0LjM1NSIgLz4KICA8cGF0aCBkPSJNMTkgMTZ2NiIgLz4KICA8cGF0aCBkPSJNNiAxMEg0YTIgMiAwIDAwLTIgMnY3YTIgMiAwIDAwMiAyaDguNTM1IiAvPgogIDxwYXRoIGQ9Ik02IDIxVjVhMiAyIDAgMDEyLTJoOGEyIDIgMCAwMTIgMnY3LjEyNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/building-complex-plus
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BuildingComplexPlus = createLucideIcon(__iconData);

export default BuildingComplexPlus;
