import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'calendar-off',
  size: 24,
  node: [
    ['path', { d: 'M16 2v3', key: 'otl347' }],
    ['path', { d: 'm2 2 20 20', key: '1ooewy' }],
    ['path', { d: 'M21 9h-5.5', key: '1g344v' }],
    ['path', { d: 'M3 9h6', key: '1q2djq' }],
    ['path', { d: 'M3.586 3.586A2 2 0 003 5v14a2 2 0 002 2h14a2 2 0 001.414-.586', key: '1g7ltu' }],
    ['path', { d: 'M8.656 3H19a2 2 0 012 2v10.344', key: '1bwpd1' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CalendarOff
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTYgMnYzIiAvPgogIDxwYXRoIGQ9Im0yIDIgMjAgMjAiIC8+CiAgPHBhdGggZD0iTTIxIDloLTUuNSIgLz4KICA8cGF0aCBkPSJNMyA5aDYiIC8+CiAgPHBhdGggZD0iTTMuNTg2IDMuNTg2QTIgMiAwIDAwMyA1djE0YTIgMiAwIDAwMiAyaDE0YTIgMiAwIDAwMS40MTQtLjU4NiIgLz4KICA8cGF0aCBkPSJNOC42NTYgM0gxOWEyIDIgMCAwMTIgMnYxMC4zNDQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/calendar-off
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CalendarOff = createLucideIcon(__iconData);

export default CalendarOff;
