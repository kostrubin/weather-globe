import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'broom-sparkles',
  size: 24,
  node: [
    ['path', { d: 'M11 2v2', key: '1539x4' }],
    ['path', { d: 'M12 3h-2', key: '1su5n0' }],
    ['path', { d: 'M13.5 10.5 22 2', key: '1yxz6l' }],
    [
      'path',
      {
        d: 'M14.734 13.841a2 2 0 00-.314-2.42L12.58 9.58a2 2 0 00-2.421-.314l-7.657 4.461A1 1 0 002.3 15.3l6.403 6.403a1 1 0 001.571-.204z',
        key: '1q75r6',
      },
    ],
    ['path', { d: 'M20 15v4', key: 'nmhudv' }],
    ['path', { d: 'M22 17h-4', key: '1sj068' }],
    ['path', { d: 'M4 4v4', key: 'a4sqb9' }],
    ['path', { d: 'm5 18 2-2', key: '11qwpn' }],
    ['path', { d: 'M6 6H2', key: '1cli1h' }],
    ['path', { d: 'm7.699 10.7 5.602 5.601', key: '1rehuz' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BroomSparkles
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTEgMnYyIiAvPgogIDxwYXRoIGQ9Ik0xMiAzaC0yIiAvPgogIDxwYXRoIGQ9Ik0xMy41IDEwLjUgMjIgMiIgLz4KICA8cGF0aCBkPSJNMTQuNzM0IDEzLjg0MWEyIDIgMCAwMC0uMzE0LTIuNDJMMTIuNTggOS41OGEyIDIgMCAwMC0yLjQyMS0uMzE0bC03LjY1NyA0LjQ2MUExIDEgMCAwMDIuMyAxNS4zbDYuNDAzIDYuNDAzYTEgMSAwIDAwMS41NzEtLjIwNHoiIC8+CiAgPHBhdGggZD0iTTIwIDE1djQiIC8+CiAgPHBhdGggZD0iTTIyIDE3aC00IiAvPgogIDxwYXRoIGQ9Ik00IDR2NCIgLz4KICA8cGF0aCBkPSJtNSAxOCAyLTIiIC8+CiAgPHBhdGggZD0iTTYgNkgyIiAvPgogIDxwYXRoIGQ9Im03LjY5OSAxMC43IDUuNjAyIDUuNjAxIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/broom-sparkles
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BroomSparkles = createLucideIcon(__iconData);

export default BroomSparkles;
