import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'carrot',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M15 16a1 1 0 0 0-7-7q-4 4-5.987 12.385a.5.5 0 0 0 .602.602Q11 20 15 16l-3-3',
        key: '1ta62j',
      },
    ],
    ['path', { d: 'M15 9q4 4 7 0-3-4-7 0 4-4 0-7-4 3 0 7', key: '1svf7i' }],
    ['path', { d: 'm8 15-2.58-2.58', key: '7t238r' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Carrot
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgMTZhMSAxIDAgMCAwLTctN3EtNCA0LTUuOTg3IDEyLjM4NWEuNS41IDAgMCAwIC42MDIuNjAyUTExIDIwIDE1IDE2bC0zLTMiIC8+CiAgPHBhdGggZD0iTTE1IDlxNCA0IDcgMC0zLTQtNyAwIDQtNCAwLTctNCAzIDAgNyIgLz4KICA8cGF0aCBkPSJtOCAxNS0yLjU4LTIuNTgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/carrot
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Carrot = createLucideIcon(__iconData);

export default Carrot;
