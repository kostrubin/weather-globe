import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'broom',
  size: 24,
  node: [
    ['path', { d: 'M13.5 10.5 22 2', key: '1yxz6l' }],
    [
      'path',
      {
        d: 'M14.734 13.841a2 2 0 00-.314-2.42L12.58 9.58a2 2 0 00-2.421-.314l-7.657 4.461A1 1 0 002.3 15.3l6.403 6.403a1 1 0 001.571-.204z',
        key: '1q75r6',
      },
    ],
    ['path', { d: 'm5 18 2-2', key: '11qwpn' }],
    ['path', { d: 'm7.699 10.7 5.602 5.601', key: '1rehuz' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Broom
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTMuNSAxMC41IDIyIDIiIC8+CiAgPHBhdGggZD0iTTE0LjczNCAxMy44NDFhMiAyIDAgMDAtLjMxNC0yLjQyTDEyLjU4IDkuNThhMiAyIDAgMDAtMi40MjEtLjMxNGwtNy42NTcgNC40NjFBMSAxIDAgMDAyLjMgMTUuM2w2LjQwMyA2LjQwM2ExIDEgMCAwMDEuNTcxLS4yMDR6IiAvPgogIDxwYXRoIGQ9Im01IDE4IDItMiIgLz4KICA8cGF0aCBkPSJtNy42OTkgMTAuNyA1LjYwMiA1LjYwMSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/broom
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Broom = createLucideIcon(__iconData);

export default Broom;
