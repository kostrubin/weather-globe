import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chess-king',
  size: 24,
  node: [
    [
      'path',
      { d: 'M4 20a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z', key: 'mqzwx6' },
    ],
    [
      'path',
      {
        d: 'm6.7 18-1-1C4.35 15.682 3 14.09 3 12a5 5 0 0 1 4.95-5c1.584 0 2.7.455 4.05 1.818C13.35 7.455 14.466 7 16.05 7A5 5 0 0 1 21 12c0 2.082-1.359 3.673-2.7 5l-1 1',
        key: '1gdt1g',
      },
    ],
    ['path', { d: 'M10 4h4', key: '1xpv9s' }],
    ['path', { d: 'M12 2v6.818', key: 'b17a49' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChessKing
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCAyMGEyIDIgMCAwIDEgMi0yaDEyYTIgMiAwIDAgMSAyIDJ2MWExIDEgMCAwIDEtMSAxSDVhMSAxIDAgMCAxLTEtMXoiIC8+CiAgPHBhdGggZD0ibTYuNyAxOC0xLTFDNC4zNSAxNS42ODIgMyAxNC4wOSAzIDEyYTUgNSAwIDAgMSA0Ljk1LTVjMS41ODQgMCAyLjcuNDU1IDQuMDUgMS44MThDMTMuMzUgNy40NTUgMTQuNDY2IDcgMTYuMDUgN0E1IDUgMCAwIDEgMjEgMTJjMCAyLjA4Mi0xLjM1OSAzLjY3My0yLjcgNWwtMSAxIiAvPgogIDxwYXRoIGQ9Ik0xMCA0aDQiIC8+CiAgPHBhdGggZD0iTTEyIDJ2Ni44MTgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chess-king
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChessKing = createLucideIcon(__iconData);

export default ChessKing;
