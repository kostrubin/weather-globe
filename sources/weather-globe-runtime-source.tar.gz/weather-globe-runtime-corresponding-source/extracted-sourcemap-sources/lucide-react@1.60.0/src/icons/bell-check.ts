import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bell-check',
  size: 24,
  node: [
    ['path', { d: 'M10.268 21a2 2 0 0 0 3.464 0', key: 'vwvbt9' }],
    ['path', { d: 'm15 8 2 2 4-4', key: 'sbrgsm' }],
    [
      'path',
      { d: 'M16.8607 4.4824A6 6 0 0 0 6 8C6 12.499 4.589 13.956 3.262 15.326', key: 'qcog4a' },
    ],
    [
      'path',
      {
        d: 'M3.262 15.326A1 1 0 0 0 4 17H20A1 1 0 0 0 20.74 15.327C20.209 14.779 19.665 14.218 19.203 13.454',
        key: 'mxnnoh',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BellCheck
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAuMjY4IDIxYTIgMiAwIDAgMCAzLjQ2NCAwIiAvPgogIDxwYXRoIGQ9Im0xNSA4IDIgMiA0LTQiIC8+CiAgPHBhdGggZD0iTTE2Ljg2MDcgNC40ODI0QTYgNiAwIDAgMCA2IDhDNiAxMi40OTkgNC41ODkgMTMuOTU2IDMuMjYyIDE1LjMyNiIgLz4KICA8cGF0aCBkPSJNMy4yNjIgMTUuMzI2QTEgMSAwIDAgMCA0IDE3SDIwQTEgMSAwIDAgMCAyMC43NCAxNS4zMjdDMjAuMjA5IDE0Ljc3OSAxOS42NjUgMTQuMjE4IDE5LjIwMyAxMy40NTQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bell-check
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BellCheck = createLucideIcon(__iconData);

export default BellCheck;
