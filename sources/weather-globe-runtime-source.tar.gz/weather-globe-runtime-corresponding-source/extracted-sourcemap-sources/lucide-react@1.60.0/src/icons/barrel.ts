import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'barrel',
  size: 24,
  node: [
    ['path', { d: 'M10.5 2a34.5 34.5 0 000 20', key: '101rs3' }],
    ['path', { d: 'M13.5 2a34.5 34.5 0 010 20', key: 'op77mm' }],
    ['path', { d: 'M4.67 17h14.67', key: 'qzi5u0' }],
    ['path', { d: 'M4.67 7h14.67', key: '1fzc0z' }],
    [
      'path',
      {
        d: 'M6.23 3.06a19 19 0 000 17.88A2 2 0 008 22h8a2 2 0 001.77-1.06 19 19 0 000-17.88A2 2 0 0016 2H8a2 2 0 00-1.77 1.06',
        key: '161s4t',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Barrel
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAuNSAyYTM0LjUgMzQuNSAwIDAwMCAyMCIgLz4KICA8cGF0aCBkPSJNMTMuNSAyYTM0LjUgMzQuNSAwIDAxMCAyMCIgLz4KICA8cGF0aCBkPSJNNC42NyAxN2gxNC42NyIgLz4KICA8cGF0aCBkPSJNNC42NyA3aDE0LjY3IiAvPgogIDxwYXRoIGQ9Ik02LjIzIDMuMDZhMTkgMTkgMCAwMDAgMTcuODhBMiAyIDAgMDA4IDIyaDhhMiAyIDAgMDAxLjc3LTEuMDYgMTkgMTkgMCAwMDAtMTcuODhBMiAyIDAgMDAxNiAySDhhMiAyIDAgMDAtMS43NyAxLjA2IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/barrel
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Barrel = createLucideIcon(__iconData);

export default Barrel;
