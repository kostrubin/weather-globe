import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chess-rook',
  size: 24,
  node: [
    [
      'path',
      { d: 'M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z', key: 'b89hwq' },
    ],
    ['path', { d: 'M10 2v2', key: '7u0qdc' }],
    ['path', { d: 'M14 2v2', key: '6buw04' }],
    ['path', { d: 'm17 18-1-9', key: '10nd7q' }],
    ['path', { d: 'M6 2v5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2', key: 'uxf4yx' }],
    ['path', { d: 'M6 4h12', key: '1x2ag7' }],
    ['path', { d: 'm7 18 1-9', key: '1si9vq' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChessRook
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAyMGEyIDIgMCAwIDEgMi0yaDEwYTIgMiAwIDAgMSAyIDJ2MWExIDEgMCAwIDEtMSAxSDZhMSAxIDAgMCAxLTEtMXoiIC8+CiAgPHBhdGggZD0iTTEwIDJ2MiIgLz4KICA8cGF0aCBkPSJNMTQgMnYyIiAvPgogIDxwYXRoIGQ9Im0xNyAxOC0xLTkiIC8+CiAgPHBhdGggZD0iTTYgMnY1YTIgMiAwIDAgMCAyIDJoOGEyIDIgMCAwIDAgMi0yVjIiIC8+CiAgPHBhdGggZD0iTTYgNGgxMiIgLz4KICA8cGF0aCBkPSJtNyAxOCAxLTkiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chess-rook
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChessRook = createLucideIcon(__iconData);

export default ChessRook;
