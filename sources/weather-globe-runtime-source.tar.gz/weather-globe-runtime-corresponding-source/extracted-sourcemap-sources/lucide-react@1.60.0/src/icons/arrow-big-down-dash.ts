import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'arrow-big-down-dash',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M14 8a1 1 0 0 1 1 1v2a1 1 0 0 0 1 1h3.293a.707.707 0 0 1 .5 1.207l-6.939 6.939a1.207 1.207 0 0 1-1.708 0l-6.94-6.94a.707.707 0 0 1 .5-1.206H8a1 1 0 0 0 1-1V9a1 1 0 0 1 1-1z',
        key: '1b91ra',
      },
    ],
    ['path', { d: 'M9 4h6', key: '10am2s' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ArrowBigDownDash
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQgOGExIDEgMCAwIDEgMSAxdjJhMSAxIDAgMCAwIDEgMWgzLjI5M2EuNzA3LjcwNyAwIDAgMSAuNSAxLjIwN2wtNi45MzkgNi45MzlhMS4yMDcgMS4yMDcgMCAwIDEtMS43MDggMGwtNi45NC02Ljk0YS43MDcuNzA3IDAgMCAxIC41LTEuMjA2SDhhMSAxIDAgMCAwIDEtMVY5YTEgMSAwIDAgMSAxLTF6IiAvPgogIDxwYXRoIGQ9Ik05IDRoNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/arrow-big-down-dash
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ArrowBigDownDash = createLucideIcon(__iconData);

export default ArrowBigDownDash;
