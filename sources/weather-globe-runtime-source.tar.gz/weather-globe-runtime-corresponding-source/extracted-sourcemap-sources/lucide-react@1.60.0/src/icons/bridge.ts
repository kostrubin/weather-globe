import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bridge',
  size: 24,
  node: [
    ['path', { d: 'M10 9.728V16', key: 'o67grx' }],
    ['path', { d: 'M14 9.728V16', key: 'podb55' }],
    ['path', { d: 'M18 20V4', key: 'o2hl4u' }],
    ['path', { d: 'm22 11-4-4A7.5 7.5 0 0 1 6 7l-4 4', key: 'uc7s7' }],
    ['path', { d: 'M22 16H2', key: '142mmy' }],
    ['path', { d: 'M6 20V4', key: '1w1bmo' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Bridge
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgOS43MjhWMTYiIC8+CiAgPHBhdGggZD0iTTE0IDkuNzI4VjE2IiAvPgogIDxwYXRoIGQ9Ik0xOCAyMFY0IiAvPgogIDxwYXRoIGQ9Im0yMiAxMS00LTRBNy41IDcuNSAwIDAgMSA2IDdsLTQgNCIgLz4KICA8cGF0aCBkPSJNMjIgMTZIMiIgLz4KICA8cGF0aCBkPSJNNiAyMFY0IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/bridge
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Bridge = createLucideIcon(__iconData);

export default Bridge;
