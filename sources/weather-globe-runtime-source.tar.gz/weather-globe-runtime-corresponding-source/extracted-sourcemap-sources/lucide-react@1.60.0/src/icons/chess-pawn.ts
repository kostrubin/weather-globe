import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chess-pawn',
  size: 24,
  node: [
    [
      'path',
      { d: 'M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z', key: 'b89hwq' },
    ],
    ['path', { d: 'm14.5 10 1.5 8', key: 'cim3qy' }],
    ['path', { d: 'M7 10h10', key: '1101jm' }],
    ['path', { d: 'm8 18 1.5-8', key: 'ja3yjd' }],
    ['circle', { cx: '12', cy: '6', r: '4', key: '1frrej' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChessPawn
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAyMGEyIDIgMCAwIDEgMi0yaDEwYTIgMiAwIDAgMSAyIDJ2MWExIDEgMCAwIDEtMSAxSDZhMSAxIDAgMCAxLTEtMXoiIC8+CiAgPHBhdGggZD0ibTE0LjUgMTAgMS41IDgiIC8+CiAgPHBhdGggZD0iTTcgMTBoMTAiIC8+CiAgPHBhdGggZD0ibTggMTggMS41LTgiIC8+CiAgPGNpcmNsZSBjeD0iMTIiIGN5PSI2IiByPSI0IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/chess-pawn
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChessPawn = createLucideIcon(__iconData);

export default ChessPawn;
