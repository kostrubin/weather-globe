import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'certificate',
  size: 24,
  node: [
    ['path', { d: 'M12 10H6', key: '1xtf46' }],
    [
      'path',
      {
        d: 'm20.69 15.479 1.29 4.88a.5.5 0 01-.698.591l-1.843-.849a1 1 0 00-.879.001l-1.846.85a.5.5 0 01-.692-.593l1.29-4.88',
        key: 'gisnvv',
      },
    ],
    ['path', { d: 'M22 6.675V6a2 2 0 00-2-2H4a2 2 0 00-2 2v12a2 2 0 002 2h8', key: '1ml1d0' }],
    ['path', { d: 'M6 14h4', key: '1pohh5' }],
    ['circle', { cx: '19', cy: '13', r: '3', key: '1rjyw2' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Certificate
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMTBINiIgLz4KICA8cGF0aCBkPSJtMjAuNjkgMTUuNDc5IDEuMjkgNC44OGEuNS41IDAgMDEtLjY5OC41OTFsLTEuODQzLS44NDlhMSAxIDAgMDAtLjg3OS4wMDFsLTEuODQ2Ljg1YS41LjUgMCAwMS0uNjkyLS41OTNsMS4yOS00Ljg4IiAvPgogIDxwYXRoIGQ9Ik0yMiA2LjY3NVY2YTIgMiAwIDAwLTItMkg0YTIgMiAwIDAwLTIgMnYxMmEyIDIgMCAwMDIgMmg4IiAvPgogIDxwYXRoIGQ9Ik02IDE0aDQiIC8+CiAgPGNpcmNsZSBjeD0iMTkiIGN5PSIxMyIgcj0iMyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/certificate
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Certificate = createLucideIcon(__iconData);

export default Certificate;
