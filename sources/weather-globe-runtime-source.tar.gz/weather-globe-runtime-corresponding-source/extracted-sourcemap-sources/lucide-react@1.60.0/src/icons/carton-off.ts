import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'carton-off',
  size: 24,
  node: [
    ['path', { d: 'M10 10H5v10a2 2 0 002 2h10a2 2 0 002-2v-1', key: 'a96p2r' }],
    ['path', { d: 'M13 22v-9', key: '1nhnq0' }],
    ['path', { d: 'M13.902 8.245 16 6h-4.343', key: '19phw3' }],
    [
      'path',
      {
        d: 'M19 13.343V10a2 2 0 00-.539-1.367L16 6V3a1 1 0 00-1-1H9a1 1 0 00-.857.486',
        key: 'afhpp5',
      },
    ],
    ['path', { d: 'm2 2 20 20', key: '1ooewy' }],
    ['path', { d: 'M7.034 7.034 5.539 8.633A2 2 0 005 10', key: '1798p5' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CartonOff
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgMTBINXYxMGEyIDIgMCAwMDIgMmgxMGEyIDIgMCAwMDItMnYtMSIgLz4KICA8cGF0aCBkPSJNMTMgMjJ2LTkiIC8+CiAgPHBhdGggZD0iTTEzLjkwMiA4LjI0NSAxNiA2aC00LjM0MyIgLz4KICA8cGF0aCBkPSJNMTkgMTMuMzQzVjEwYTIgMiAwIDAwLS41MzktMS4zNjdMMTYgNlYzYTEgMSAwIDAwLTEtMUg5YTEgMSAwIDAwLS44NTcuNDg2IiAvPgogIDxwYXRoIGQ9Im0yIDIgMjAgMjAiIC8+CiAgPHBhdGggZD0iTTcuMDM0IDcuMDM0IDUuNTM5IDguNjMzQTIgMiAwIDAwNSAxMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/carton-off
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CartonOff = createLucideIcon(__iconData);

export default CartonOff;
