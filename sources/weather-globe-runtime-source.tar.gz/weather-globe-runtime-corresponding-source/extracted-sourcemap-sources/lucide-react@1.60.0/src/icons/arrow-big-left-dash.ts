import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'arrow-big-left-dash',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M13 9a1 1 0 0 1-1-1V4.707a.707.707 0 0 0-1.207-.5l-6.94 6.94a1.207 1.207 0 0 0 0 1.707l6.94 6.94a.707.707 0 0 0 1.207-.5V16a1 1 0 0 1 1-1h2a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1z',
        key: '17jy80',
      },
    ],
    ['path', { d: 'M20 9v6', key: '14roy0' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ArrowBigLeftDash
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTMgOWExIDEgMCAwIDEtMS0xVjQuNzA3YS43MDcuNzA3IDAgMCAwLTEuMjA3LS41bC02Ljk0IDYuOTRhMS4yMDcgMS4yMDcgMCAwIDAgMCAxLjcwN2w2Ljk0IDYuOTRhLjcwNy43MDcgMCAwIDAgMS4yMDctLjVWMTZhMSAxIDAgMCAxIDEtMWgyYTEgMSAwIDAgMCAxLTF2LTRhMSAxIDAgMCAwLTEtMXoiIC8+CiAgPHBhdGggZD0iTTIwIDl2NiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/arrow-big-left-dash
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ArrowBigLeftDash = createLucideIcon(__iconData);

export default ArrowBigLeftDash;
