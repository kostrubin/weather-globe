import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'calendar-plus-2',
  size: 24,
  node: [
    ['path', { d: 'M8 2v3', key: '1ioesn' }],
    ['path', { d: 'M16 2v3', key: 'otl347' }],
    ['rect', { x: '3', y: '3', width: '18', height: '18', rx: '2', key: 'h1oib' }],
    ['path', { d: 'M3 9h18', key: '1pudct' }],
    ['path', { d: 'M10 15h4', key: '192ueg' }],
    ['path', { d: 'M12 13v4', key: '1il4po' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CalendarPlus2
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNOCAydjMiIC8+CiAgPHBhdGggZD0iTTE2IDJ2MyIgLz4KICA8cmVjdCB4PSIzIiB5PSIzIiB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHJ4PSIyIiAvPgogIDxwYXRoIGQ9Ik0zIDloMTgiIC8+CiAgPHBhdGggZD0iTTEwIDE1aDQiIC8+CiAgPHBhdGggZD0iTTEyIDEzdjQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/calendar-plus-2
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CalendarPlus2 = createLucideIcon(__iconData);

export default CalendarPlus2;
