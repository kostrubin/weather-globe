import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chart-no-axes-column-decreasing',
  size: 24,
  node: [
    ['path', { d: 'M5 21V3', key: 'clc1r8' }],
    ['path', { d: 'M12 21V9', key: 'uvy0l4' }],
    ['path', { d: 'M19 21v-6', key: 'tkawy9' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChartNoAxesColumnDecreasing
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAyMVYzIiAvPgogIDxwYXRoIGQ9Ik0xMiAyMVY5IiAvPgogIDxwYXRoIGQ9Ik0xOSAyMXYtNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/chart-no-axes-column-decreasing
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChartNoAxesColumnDecreasing = createLucideIcon(__iconData);

export default ChartNoAxesColumnDecreasing;
