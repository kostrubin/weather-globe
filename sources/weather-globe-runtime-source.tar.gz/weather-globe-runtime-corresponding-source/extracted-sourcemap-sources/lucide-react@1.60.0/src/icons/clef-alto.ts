import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'clef-alto',
  size: 24,
  node: [
    ['path', { d: 'M10 4v16', key: '14ds90' }],
    [
      'path',
      {
        d: 'M14 4.764a3 3 0 1 1-.152 4.327A4 4 0 0 1 10 12a4 4 0 0 1 3.848 2.909A3 3 0 1 1 14 19.236',
        key: 'udi1dj',
      },
    ],
    ['path', { d: 'M6 4v16', key: 'n0nszo' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ClefAlto
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgNHYxNiIgLz4KICA8cGF0aCBkPSJNMTQgNC43NjRhMyAzIDAgMSAxLS4xNTIgNC4zMjdBNCA0IDAgMCAxIDEwIDEyYTQgNCAwIDAgMSAzLjg0OCAyLjkwOUEzIDMgMCAxIDEgMTQgMTkuMjM2IiAvPgogIDxwYXRoIGQ9Ik02IDR2MTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/clef-alto
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ClefAlto = createLucideIcon(__iconData);

export default ClefAlto;
