import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'can-soda',
  size: 24,
  node: [
    [
      'path',
      { d: 'm17 22 1.664-2.496a2 2 0 00.336-1.11V5.606a2 2 0 00-.336-1.11L17 2', key: '8r63so' },
    ],
    ['path', { d: 'M18 22H6', key: 'mg6kv4' }],
    ['path', { d: 'M18 2H6', key: '10w3qr' }],
    ['path', { d: 'M5 17h14', key: '74xsq1' }],
    ['path', { d: 'M5 7h14', key: '1ic0q6' }],
    [
      'path',
      { d: 'm7 22-1.664-2.496A2 2 0 015 18.394V5.606a2 2 0 01.336-1.11L7 2', key: 'p59xmm' },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CanSoda
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTcgMjIgMS42NjQtMi40OTZhMiAyIDAgMDAuMzM2LTEuMTFWNS42MDZhMiAyIDAgMDAtLjMzNi0xLjExTDE3IDIiIC8+CiAgPHBhdGggZD0iTTE4IDIySDYiIC8+CiAgPHBhdGggZD0iTTE4IDJINiIgLz4KICA8cGF0aCBkPSJNNSAxN2gxNCIgLz4KICA8cGF0aCBkPSJNNSA3aDE0IiAvPgogIDxwYXRoIGQ9Im03IDIyLTEuNjY0LTIuNDk2QTIgMiAwIDAxNSAxOC4zOTRWNS42MDZhMiAyIDAgMDEuMzM2LTEuMTFMNyAyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/can-soda
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CanSoda = createLucideIcon(__iconData);

export default CanSoda;
