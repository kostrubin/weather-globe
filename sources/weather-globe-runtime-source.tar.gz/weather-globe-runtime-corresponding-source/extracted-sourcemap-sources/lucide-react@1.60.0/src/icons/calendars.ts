import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'calendars',
  size: 24,
  node: [
    ['path', { d: 'M12 2v2', key: 'tus03m' }],
    [
      'path',
      { d: 'M15.726 21.01A2 2 0 0 1 14 22H4a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2', key: 'j6srht' },
    ],
    ['path', { d: 'M18 2v2', key: '1kh14s' }],
    ['path', { d: 'M2 13h2', key: '13gyu8' }],
    ['path', { d: 'M8 8h14', key: '12jxz2' }],
    ['rect', { x: '8', y: '3', width: '14', height: '14', rx: '2', key: 'nsru6w' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Calendars
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMnYyIiAvPgogIDxwYXRoIGQ9Ik0xNS43MjYgMjEuMDFBMiAyIDAgMCAxIDE0IDIySDRhMiAyIDAgMCAxLTItMlYxMGEyIDIgMCAwIDEgMi0yIiAvPgogIDxwYXRoIGQ9Ik0xOCAydjIiIC8+CiAgPHBhdGggZD0iTTIgMTNoMiIgLz4KICA8cGF0aCBkPSJNOCA4aDE0IiAvPgogIDxyZWN0IHg9IjgiIHk9IjMiIHdpZHRoPSIxNCIgaGVpZ2h0PSIxNCIgcng9IjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/calendars
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Calendars = createLucideIcon(__iconData);

export default Calendars;
