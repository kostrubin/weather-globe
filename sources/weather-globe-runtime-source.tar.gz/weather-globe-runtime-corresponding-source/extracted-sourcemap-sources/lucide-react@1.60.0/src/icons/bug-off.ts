import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bug-off',
  size: 24,
  node: [
    ['path', { d: 'M12 20v-8', key: 'i3yub9' }],
    ['path', { d: 'M12.656 7H14a4 4 0 0 1 4 4v1.344', key: 'vvueyn' }],
    ['path', { d: 'M14.12 3.88 16 2', key: 'qol33r' }],
    ['path', { d: 'M17.123 17.123A6 6 0 0 1 6 14v-3a4 4 0 0 1 1.72-3.287', key: '1cu21y' }],
    ['path', { d: 'm2 2 20 20', key: '1ooewy' }],
    ['path', { d: 'M21 5a4 4 0 0 1-3.55 3.97', key: '5cxbf6' }],
    ['path', { d: 'M22 13h-3.344', key: 'qb08am' }],
    ['path', { d: 'M3 21a4 4 0 0 1 3.81-4', key: '1fjd4g' }],
    ['path', { d: 'M3 5a4 4 0 0 0 3.55 3.97', key: '1d7oge' }],
    ['path', { d: 'M6 13H2', key: '82j7cp' }],
    ['path', { d: 'm8 2 1.88 1.88', key: 'fmnt4t' }],
    ['path', { d: 'M9.712 4.06A3 3 0 0 1 15 6v1.13', key: '1bvup6' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BugOff
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMjB2LTgiIC8+CiAgPHBhdGggZD0iTTEyLjY1NiA3SDE0YTQgNCAwIDAgMSA0IDR2MS4zNDQiIC8+CiAgPHBhdGggZD0iTTE0LjEyIDMuODggMTYgMiIgLz4KICA8cGF0aCBkPSJNMTcuMTIzIDE3LjEyM0E2IDYgMCAwIDEgNiAxNHYtM2E0IDQgMCAwIDEgMS43Mi0zLjI4NyIgLz4KICA8cGF0aCBkPSJtMiAyIDIwIDIwIiAvPgogIDxwYXRoIGQ9Ik0yMSA1YTQgNCAwIDAgMS0zLjU1IDMuOTciIC8+CiAgPHBhdGggZD0iTTIyIDEzaC0zLjM0NCIgLz4KICA8cGF0aCBkPSJNMyAyMWE0IDQgMCAwIDEgMy44MS00IiAvPgogIDxwYXRoIGQ9Ik0zIDVhNCA0IDAgMCAwIDMuNTUgMy45NyIgLz4KICA8cGF0aCBkPSJNNiAxM0gyIiAvPgogIDxwYXRoIGQ9Im04IDIgMS44OCAxLjg4IiAvPgogIDxwYXRoIGQ9Ik05LjcxMiA0LjA2QTMgMyAwIDAgMSAxNSA2djEuMTMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bug-off
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BugOff = createLucideIcon(__iconData);

export default BugOff;
