import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'cannabis-off',
  size: 24,
  node: [
    ['path', { d: 'M12 22v-4c1.5 1.5 3.5 3 6 3 0-1.5-.5-3.5-2-5', key: '1bqfb7' }],
    [
      'path',
      { d: 'M13.988 8.327C13.902 6.054 13.365 3.82 12 2a9.3 9.3 0 0 0-1.445 2.9', key: '1p520n' },
    ],
    [
      'path',
      {
        d: 'M17.375 11.725C18.882 10.53 21 7.841 21 6c-2.324 0-5.08 1.296-6.662 2.684',
        key: 'q2itvb',
      },
    ],
    ['path', { d: 'm2 2 20 20', key: '1ooewy' }],
    [
      'path',
      { d: 'M21.024 15.378A15 15 0 0 0 22 15c-.426-1.279-2.67-2.557-4.25-2.907', key: 'j9amvs' },
    ],
    [
      'path',
      {
        d: 'M6.995 6.992C5.714 6.4 4.29 6 3 6c0 2 2.5 5 4 6-1.5 0-4.5 1.5-5 3 3.5 1.5 6 1 6 1-1.5 1.5-2 3.5-2 5 2.5 0 4.5-1.5 6-3',
        key: '8gmd5g',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CannabisOff
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMjJ2LTRjMS41IDEuNSAzLjUgMyA2IDMgMC0xLjUtLjUtMy41LTItNSIgLz4KICA8cGF0aCBkPSJNMTMuOTg4IDguMzI3QzEzLjkwMiA2LjA1NCAxMy4zNjUgMy44MiAxMiAyYTkuMyA5LjMgMCAwIDAtMS40NDUgMi45IiAvPgogIDxwYXRoIGQ9Ik0xNy4zNzUgMTEuNzI1QzE4Ljg4MiAxMC41MyAyMSA3Ljg0MSAyMSA2Yy0yLjMyNCAwLTUuMDggMS4yOTYtNi42NjIgMi42ODQiIC8+CiAgPHBhdGggZD0ibTIgMiAyMCAyMCIgLz4KICA8cGF0aCBkPSJNMjEuMDI0IDE1LjM3OEExNSAxNSAwIDAgMCAyMiAxNWMtLjQyNi0xLjI3OS0yLjY3LTIuNTU3LTQuMjUtMi45MDciIC8+CiAgPHBhdGggZD0iTTYuOTk1IDYuOTkyQzUuNzE0IDYuNCA0LjI5IDYgMyA2YzAgMiAyLjUgNSA0IDYtMS41IDAtNC41IDEuNS01IDMgMy41IDEuNSA2IDEgNiAxLTEuNSAxLjUtMiAzLjUtMiA1IDIuNSAwIDQuNS0xLjUgNi0zIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/cannabis-off
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CannabisOff = createLucideIcon(__iconData);

export default CannabisOff;
