import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'calendar-sync',
  size: 24,
  node: [
    ['path', { d: 'M11 10v4h4', key: '172dkj' }],
    ['path', { d: 'm11 14 1.535-1.605a5 5 0 018 1.5', key: 'jekqcd' }],
    ['path', { d: 'M16 2v3', key: 'otl347' }],
    ['path', { d: 'm21 18-1.535 1.605a5 5 0 01-8-1.5', key: 'n107hu' }],
    ['path', { d: 'M21 22v-4h-4', key: 'hrummi' }],
    ['path', { d: 'M21 8.517V5a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2h3.517', key: 'yafrba' }],
    ['path', { d: 'M3 9h4', key: 'rnfnj5' }],
    ['path', { d: 'M8 2v3', key: '1ioesn' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CalendarSync
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTEgMTB2NGg0IiAvPgogIDxwYXRoIGQ9Im0xMSAxNCAxLjUzNS0xLjYwNWE1IDUgMCAwMTggMS41IiAvPgogIDxwYXRoIGQ9Ik0xNiAydjMiIC8+CiAgPHBhdGggZD0ibTIxIDE4LTEuNTM1IDEuNjA1YTUgNSAwIDAxLTgtMS41IiAvPgogIDxwYXRoIGQ9Ik0yMSAyMnYtNGgtNCIgLz4KICA8cGF0aCBkPSJNMjEgOC41MTdWNWEyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTRhMiAyIDAgMDAyIDJoMy41MTciIC8+CiAgPHBhdGggZD0iTTMgOWg0IiAvPgogIDxwYXRoIGQ9Ik04IDJ2MyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/calendar-sync
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CalendarSync = createLucideIcon(__iconData);

export default CalendarSync;
