import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'cctv-off',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'm12.309 6.652 4.797 2.401a1 1 0 0 1 .447 1.341l-.501 1.001.605.605h2.725a1 1 0 0 1 .894 1.447l-.724 1.448',
        key: 'e75roo',
      },
    ],
    [
      'path',
      {
        d: 'm15.166 15.166-.719 1.439a1 1 0 0 1-1.342.447L3.61 12.3a2.92 2.92 0 0 1-1.3-3.91L3.69 5.6a2.9 2.9 0 0 1 .873-1.037',
        key: '1h9o5r',
      },
    ],
    ['path', { d: 'M2 19h3.76a2 2 0 0 0 1.8-1.1l1.441-2.902', key: '1askrb' }],
    ['path', { d: 'm2 2 20 20', key: '1ooewy' }],
    ['path', { d: 'M2 21v-4', key: 'l40lih' }],
    ['path', { d: 'M7 9h.01', key: '19b3jx' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CctvOff
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTIuMzA5IDYuNjUyIDQuNzk3IDIuNDAxYTEgMSAwIDAgMSAuNDQ3IDEuMzQxbC0uNTAxIDEuMDAxLjYwNS42MDVoMi43MjVhMSAxIDAgMCAxIC44OTQgMS40NDdsLS43MjQgMS40NDgiIC8+CiAgPHBhdGggZD0ibTE1LjE2NiAxNS4xNjYtLjcxOSAxLjQzOWExIDEgMCAwIDEtMS4zNDIuNDQ3TDMuNjEgMTIuM2EyLjkyIDIuOTIgMCAwIDEtMS4zLTMuOTFMMy42OSA1LjZhMi45IDIuOSAwIDAgMSAuODczLTEuMDM3IiAvPgogIDxwYXRoIGQ9Ik0yIDE5aDMuNzZhMiAyIDAgMCAwIDEuOC0xLjFsMS40NDEtMi45MDIiIC8+CiAgPHBhdGggZD0ibTIgMiAyMCAyMCIgLz4KICA8cGF0aCBkPSJNMiAyMXYtNCIgLz4KICA8cGF0aCBkPSJNNyA5aC4wMSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/cctv-off
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CctvOff = createLucideIcon(__iconData);

export default CctvOff;
