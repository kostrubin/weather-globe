import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'case-sensitive',
  size: 24,
  node: [
    ['path', { d: 'm2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16', key: 'd5nyq2' }],
    ['path', { d: 'M22 9v7', key: 'pvm9v3' }],
    ['path', { d: 'M3.304 13h6.392', key: '1q3zxz' }],
    ['circle', { cx: '18.5', cy: '12.5', r: '3.5', key: 'z97x68' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CaseSensitive
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMiAxNiA0LjAzOS05LjY5YS41LjUgMCAwIDEgLjkyMyAwTDExIDE2IiAvPgogIDxwYXRoIGQ9Ik0yMiA5djciIC8+CiAgPHBhdGggZD0iTTMuMzA0IDEzaDYuMzkyIiAvPgogIDxjaXJjbGUgY3g9IjE4LjUiIGN5PSIxMi41IiByPSIzLjUiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/case-sensitive
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CaseSensitive = createLucideIcon(__iconData);

export default CaseSensitive;
