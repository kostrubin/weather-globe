import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'armenian-dram',
  size: 24,
  node: [
    ['path', { d: 'M11 10h8', key: 'cn0dty' }],
    ['path', { d: 'M11 14h8', key: 'lksjnm' }],
    ['path', { d: 'M17 20V10a6 6 0 0 0-12 0', key: '1gdsmd' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ArmenianDram
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTEgMTBoOCIgLz4KICA8cGF0aCBkPSJNMTEgMTRoOCIgLz4KICA8cGF0aCBkPSJNMTcgMjBWMTBhNiA2IDAgMCAwLTEyIDAiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/armenian-dram
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ArmenianDram = createLucideIcon(__iconData);

export default ArmenianDram;
