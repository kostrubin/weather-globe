import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chess-knight',
  size: 24,
  node: [
    [
      'path',
      { d: 'M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z', key: 'b89hwq' },
    ],
    [
      'path',
      {
        d: 'M16.5 18c1-2 2.5-5 2.5-9a7 7 0 0 0-7-7H6.635a1 1 0 0 0-.768 1.64L7 5l-2.32 5.802a2 2 0 0 0 .95 2.526l2.87 1.456',
        key: 'axbnlq',
      },
    ],
    ['path', { d: 'm15 5 1.425-1.425', key: '15xz8w' }],
    ['path', { d: 'm17 8 1.53-1.53', key: '15zhqh' }],
    ['path', { d: 'M9.713 12.185 7 18', key: '1ocm0l' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChessKnight
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSAyMGEyIDIgMCAwIDEgMi0yaDEwYTIgMiAwIDAgMSAyIDJ2MWExIDEgMCAwIDEtMSAxSDZhMSAxIDAgMCAxLTEtMXoiIC8+CiAgPHBhdGggZD0iTTE2LjUgMThjMS0yIDIuNS01IDIuNS05YTcgNyAwIDAgMC03LTdINi42MzVhMSAxIDAgMCAwLS43NjggMS42NEw3IDVsLTIuMzIgNS44MDJhMiAyIDAgMCAwIC45NSAyLjUyNmwyLjg3IDEuNDU2IiAvPgogIDxwYXRoIGQ9Im0xNSA1IDEuNDI1LTEuNDI1IiAvPgogIDxwYXRoIGQ9Im0xNyA4IDEuNTMtMS41MyIgLz4KICA8cGF0aCBkPSJNOS43MTMgMTIuMTg1IDcgMTgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chess-knight
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChessKnight = createLucideIcon(__iconData);

export default ChessKnight;
