import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'balloon',
  size: 24,
  node: [
    ['path', { d: 'M12 16v1a2 2 0 0 0 2 2h1a2 2 0 0 1 2 2v1', key: '2nz4b' }],
    ['path', { d: 'M12 6a2 2 0 0 1 2 2', key: '7y7d82' }],
    ['path', { d: 'M18 8c0 4-3.5 8-6 8s-6-4-6-8a6 6 0 0 1 12 0', key: 'vqb5s3' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Balloon
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMTZ2MWEyIDIgMCAwIDAgMiAyaDFhMiAyIDAgMCAxIDIgMnYxIiAvPgogIDxwYXRoIGQ9Ik0xMiA2YTIgMiAwIDAgMSAyIDIiIC8+CiAgPHBhdGggZD0iTTE4IDhjMCA0LTMuNSA4LTYgOHMtNi00LTYtOGE2IDYgMCAwIDEgMTIgMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/balloon
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Balloon = createLucideIcon(__iconData);

export default Balloon;
