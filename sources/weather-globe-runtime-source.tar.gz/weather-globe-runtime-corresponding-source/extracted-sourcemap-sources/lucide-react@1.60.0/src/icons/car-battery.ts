import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'car-battery',
  size: 24,
  node: [
    ['path', { d: 'M14 13h4', key: 'xb9564' }],
    ['path', { d: 'M16 15v-4', key: 'rpmtp7' }],
    ['path', { d: 'M18 5v2', key: 'n2sebz' }],
    ['path', { d: 'M6 13h4', key: 'vm80m7' }],
    ['path', { d: 'M6 5v2', key: 'h3tt00' }],
    ['rect', { x: '2', y: '7', width: '20', height: '12', rx: '2', key: 'uzf593' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CarBattery
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQgMTNoNCIgLz4KICA8cGF0aCBkPSJNMTYgMTV2LTQiIC8+CiAgPHBhdGggZD0iTTE4IDV2MiIgLz4KICA8cGF0aCBkPSJNNiAxM2g0IiAvPgogIDxwYXRoIGQ9Ik02IDV2MiIgLz4KICA8cmVjdCB4PSIyIiB5PSI3IiB3aWR0aD0iMjAiIGhlaWdodD0iMTIiIHJ4PSIyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/car-battery
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CarBattery = createLucideIcon(__iconData);

export default CarBattery;
