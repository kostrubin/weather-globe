import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'cake-slice',
  size: 24,
  node: [
    ['path', { d: 'M16 13H3', key: '1wpj08' }],
    ['path', { d: 'M16 17H3', key: '3lvfcd' }],
    [
      'path',
      {
        d: 'm7.2 7.9-3.388 2.5A2 2 0 0 0 3 12.01V20a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-8.654c0-2-2.44-6.026-6.44-8.026a1 1 0 0 0-1.082.057L10.4 5.6',
        key: '1gmhf7',
      },
    ],
    ['circle', { cx: '9', cy: '7', r: '2', key: '1305pl' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CakeSlice
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTYgMTNIMyIgLz4KICA8cGF0aCBkPSJNMTYgMTdIMyIgLz4KICA8cGF0aCBkPSJtNy4yIDcuOS0zLjM4OCAyLjVBMiAyIDAgMCAwIDMgMTIuMDFWMjBhMSAxIDAgMCAwIDEgMWgxNmExIDEgMCAwIDAgMS0xdi04LjY1NGMwLTItMi40NC02LjAyNi02LjQ0LTguMDI2YTEgMSAwIDAgMC0xLjA4Mi4wNTdMMTAuNCA1LjYiIC8+CiAgPGNpcmNsZSBjeD0iOSIgY3k9IjciIHI9IjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/cake-slice
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CakeSlice = createLucideIcon(__iconData);

export default CakeSlice;
