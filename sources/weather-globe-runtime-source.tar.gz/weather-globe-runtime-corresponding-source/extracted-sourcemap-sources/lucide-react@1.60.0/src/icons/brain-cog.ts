import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'brain-cog',
  size: 24,
  node: [
    ['path', { d: 'm10.852 14.772-.383.923', key: '11vil6' }],
    ['path', { d: 'm10.852 9.228-.383-.923', key: '1fjppe' }],
    ['path', { d: 'm13.148 14.772.382.924', key: 'je3va1' }],
    ['path', { d: 'm13.53 8.305-.382.923', key: '159shc' }],
    ['path', { d: 'm14.772 10.852.923-.383', key: 'k9m8cz' }],
    ['path', { d: 'm14.772 13.148.923.383', key: '1xvhww' }],
    ['path', { d: 'M17.997 5.125a4 4 0 012.526 5.77', key: '14qhlz' }],
    ['path', { d: 'M18 18a4 4 0 002-7.464', key: '10tzm7' }],
    [
      'path',
      {
        d: 'M4.033 17.483A4 4 0 0011.46 20c.184-.31.896-.31 1.076 0a4 4 0 007.43-2.517',
        key: '19974p',
      },
    ],
    ['path', { d: 'M6 18a4 4 0 01-2-7.464', key: '17o2ag' }],
    ['path', { d: 'M6.002 5.125a4 4 0 00-2.525 5.77', key: '1vafpg' }],
    [
      'path',
      {
        d: 'M6.293 6.294a3 3 0 01-.287-1.098l-.004-.07a3 3 0 015.968-.543c.05.02.057.01.059 0a3 3 0 015.968.542l-.004.071a3 3 0 01-.287 1.098',
        key: 'l6g9lk',
      },
    ],
    ['path', { d: 'm9.228 10.852-.923-.383', key: '1wtb30' }],
    ['path', { d: 'm9.228 13.148-.923.383', key: '1a830x' }],
    ['circle', { cx: '12', cy: '12', r: '3', key: '1v7zrd' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BrainCog
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTAuODUyIDE0Ljc3Mi0uMzgzLjkyMyIgLz4KICA8cGF0aCBkPSJtMTAuODUyIDkuMjI4LS4zODMtLjkyMyIgLz4KICA8cGF0aCBkPSJtMTMuMTQ4IDE0Ljc3Mi4zODIuOTI0IiAvPgogIDxwYXRoIGQ9Im0xMy41MyA4LjMwNS0uMzgyLjkyMyIgLz4KICA8cGF0aCBkPSJtMTQuNzcyIDEwLjg1Mi45MjMtLjM4MyIgLz4KICA8cGF0aCBkPSJtMTQuNzcyIDEzLjE0OC45MjMuMzgzIiAvPgogIDxwYXRoIGQ9Ik0xNy45OTcgNS4xMjVhNCA0IDAgMDEyLjUyNiA1Ljc3IiAvPgogIDxwYXRoIGQ9Ik0xOCAxOGE0IDQgMCAwMDItNy40NjQiIC8+CiAgPHBhdGggZD0iTTQuMDMzIDE3LjQ4M0E0IDQgMCAwMDExLjQ2IDIwYy4xODQtLjMxLjg5Ni0uMzEgMS4wNzYgMGE0IDQgMCAwMDcuNDMtMi41MTciIC8+CiAgPHBhdGggZD0iTTYgMThhNCA0IDAgMDEtMi03LjQ2NCIgLz4KICA8cGF0aCBkPSJNNi4wMDIgNS4xMjVhNCA0IDAgMDAtMi41MjUgNS43NyIgLz4KICA8cGF0aCBkPSJNNi4yOTMgNi4yOTRhMyAzIDAgMDEtLjI4Ny0xLjA5OGwtLjAwNC0uMDdhMyAzIDAgMDE1Ljk2OC0uNTQzYy4wNS4wMi4wNTcuMDEuMDU5IDBhMyAzIDAgMDE1Ljk2OC41NDJsLS4wMDQuMDcxYTMgMyAwIDAxLS4yODcgMS4wOTgiIC8+CiAgPHBhdGggZD0ibTkuMjI4IDEwLjg1Mi0uOTIzLS4zODMiIC8+CiAgPHBhdGggZD0ibTkuMjI4IDEzLjE0OC0uOTIzLjM4MyIgLz4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIzIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/brain-cog
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BrainCog = createLucideIcon(__iconData);

export default BrainCog;
