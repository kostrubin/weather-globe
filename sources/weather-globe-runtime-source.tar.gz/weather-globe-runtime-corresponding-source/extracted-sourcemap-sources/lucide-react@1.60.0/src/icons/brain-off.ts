import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'brain-off',
  size: 24,
  node: [
    ['path', { d: 'M12 18v-6', key: '17g6i2' }],
    ['path', { d: 'M12 5v1.344', key: 'tksvkr' }],
    ['path', { d: 'M17.707 6.293A3 3 0 1012 5a3 3 0 00-4.124-2.781', key: '1nsar9' }],
    ['path', { d: 'M17.997 5.125a4 4 0 012.526 5.77', key: '14qhlz' }],
    ['path', { d: 'M19.644 19.644A4 4 0 0112 18a4 4 0 11-7.967-.517', key: '1to9rp' }],
    ['path', { d: 'm2 2 20 20', key: '1ooewy' }],
    ['path', { d: 'M20 10.536a4 4 0 011.533 5.34', key: '1sftkt' }],
    ['path', { d: 'M3.477 10.895a4 4 0 011.876-5.542', key: 'pom6ba' }],
    ['path', { d: 'M6 18a4 4 0 01-2-7.464', key: '17o2ag' }],
    ['path', { d: 'M9 13a4.17 4.17 0 002.166-1.5 4 4 0 00.138-.196', key: '1daz6i' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BrainOff
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMTh2LTYiIC8+CiAgPHBhdGggZD0iTTEyIDV2MS4zNDQiIC8+CiAgPHBhdGggZD0iTTE3LjcwNyA2LjI5M0EzIDMgMCAxMDEyIDVhMyAzIDAgMDAtNC4xMjQtMi43ODEiIC8+CiAgPHBhdGggZD0iTTE3Ljk5NyA1LjEyNWE0IDQgMCAwMTIuNTI2IDUuNzciIC8+CiAgPHBhdGggZD0iTTE5LjY0NCAxOS42NDRBNCA0IDAgMDExMiAxOGE0IDQgMCAxMS03Ljk2Ny0uNTE3IiAvPgogIDxwYXRoIGQ9Im0yIDIgMjAgMjAiIC8+CiAgPHBhdGggZD0iTTIwIDEwLjUzNmE0IDQgMCAwMTEuNTMzIDUuMzQiIC8+CiAgPHBhdGggZD0iTTMuNDc3IDEwLjg5NWE0IDQgMCAwMTEuODc2LTUuNTQyIiAvPgogIDxwYXRoIGQ9Ik02IDE4YTQgNCAwIDAxLTItNy40NjQiIC8+CiAgPHBhdGggZD0iTTkgMTNhNC4xNyA0LjE3IDAgMDAyLjE2Ni0xLjUgNCA0IDAgMDAuMTM4LS4xOTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/brain-off
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BrainOff = createLucideIcon(__iconData);

export default BrainOff;
