import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'calendar-check-2',
  size: 24,
  node: [
    ['path', { d: 'M 19 3 L 5 3', key: '1xn3iy' }],
    ['path', { d: 'M 21 13 L 21 5', key: '102s58' }],
    ['path', { d: 'M 21 5 A2 2 0 0 0 19 3', key: '1xylja' }],
    ['path', { d: 'M 3 19 A2 2 0 0 0 5 21', key: '19jxbv' }],
    ['path', { d: 'M 3 5 L 3 19', key: '1yylhw' }],
    ['path', { d: 'M 5 3 A2 2 0 0 0 3 5', key: '164twa' }],
    ['path', { d: 'm16 19 2 2 4-4', key: '1b14m6' }],
    ['path', { d: 'M16 2v3', key: 'otl347' }],
    ['path', { d: 'M3 9h18', key: '1pudct' }],
    ['path', { d: 'M5 21 L12.5 21', key: '1n38e0' }],
    ['path', { d: 'M8 2v3', key: '1ioesn' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CalendarCheck2
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNIDE5IDMgTCA1IDMiIC8+CiAgPHBhdGggZD0iTSAyMSAxMyBMIDIxIDUiIC8+CiAgPHBhdGggZD0iTSAyMSA1IEEyIDIgMCAwIDAgMTkgMyIgLz4KICA8cGF0aCBkPSJNIDMgMTkgQTIgMiAwIDAgMCA1IDIxIiAvPgogIDxwYXRoIGQ9Ik0gMyA1IEwgMyAxOSIgLz4KICA8cGF0aCBkPSJNIDUgMyBBMiAyIDAgMCAwIDMgNSIgLz4KICA8cGF0aCBkPSJtMTYgMTkgMiAyIDQtNCIgLz4KICA8cGF0aCBkPSJNMTYgMnYzIiAvPgogIDxwYXRoIGQ9Ik0zIDloMTgiIC8+CiAgPHBhdGggZD0iTTUgMjEgTDEyLjUgMjEiIC8+CiAgPHBhdGggZD0iTTggMnYzIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/calendar-check-2
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CalendarCheck2 = createLucideIcon(__iconData);

export default CalendarCheck2;
