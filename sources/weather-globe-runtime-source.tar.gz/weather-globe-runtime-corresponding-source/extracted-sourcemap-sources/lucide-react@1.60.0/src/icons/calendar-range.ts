import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'calendar-range',
  size: 24,
  node: [
    ['rect', { x: '3', y: '3', width: '18', height: '18', rx: '2', key: 'h1oib' }],
    ['path', { d: 'M16 2v3', key: 'otl347' }],
    ['path', { d: 'M3 9h18', key: '1pudct' }],
    ['path', { d: 'M8 2v3', key: '1ioesn' }],
    ['path', { d: 'M17 13h-6', key: '1qbiup' }],
    ['path', { d: 'M13 17H7', key: '1x38vv' }],
    ['path', { d: 'M7 13h.01', key: '1vezk1' }],
    ['path', { d: 'M17 17h.01', key: '1sd3ek' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CalendarRange
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB4PSIzIiB5PSIzIiB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHJ4PSIyIiAvPgogIDxwYXRoIGQ9Ik0xNiAydjMiIC8+CiAgPHBhdGggZD0iTTMgOWgxOCIgLz4KICA8cGF0aCBkPSJNOCAydjMiIC8+CiAgPHBhdGggZD0iTTE3IDEzaC02IiAvPgogIDxwYXRoIGQ9Ik0xMyAxN0g3IiAvPgogIDxwYXRoIGQ9Ik03IDEzaC4wMSIgLz4KICA8cGF0aCBkPSJNMTcgMTdoLjAxIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/calendar-range
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CalendarRange = createLucideIcon(__iconData);

export default CalendarRange;
