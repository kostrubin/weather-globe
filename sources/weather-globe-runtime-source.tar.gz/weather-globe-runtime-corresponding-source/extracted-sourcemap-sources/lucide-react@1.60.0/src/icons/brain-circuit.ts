import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'brain-circuit',
  size: 24,
  node: [
    ['path', { d: 'M12 13h4', key: '1ku699' }],
    ['path', { d: 'M12 18h6a2 2 0 012 2v1', key: '6s3bw4' }],
    ['path', { d: 'M12 8h8', key: '1lhi5i' }],
    ['path', { d: 'M12 9a4.17 4.17 0 01-3 4', key: '13l7kh' }],
    ['path', { d: 'M16 8V5a2 2 0 012-2', key: 'gais5y' }],
    ['path', { d: 'M6 18a4 4 0 01-2-7.465', key: '1y2m15' }],
    ['path', { d: 'M6.004 5.125a4 4 0 00-2.526 5.77', key: '3cw1ss' }],
    ['path', { d: 'M6.294 6.294A3 3 0 1112 5v13a4 4 0 11-7.967-.518', key: 'm2z1wm' }],
    ['circle', { cx: '16', cy: '13', r: '0.5', fill: 'currentColor', key: '9zzywh' }],
    ['circle', { cx: '18', cy: '3', r: '0.5', fill: 'currentColor', key: 'i2xui6' }],
    ['circle', { cx: '20', cy: '21', r: '0.5', fill: 'currentColor', key: '1dobdp' }],
    ['circle', { cx: '20', cy: '8', r: '0.5', fill: 'currentColor', key: 'r9nqlq' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BrainCircuit
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMTNoNCIgLz4KICA8cGF0aCBkPSJNMTIgMThoNmEyIDIgMCAwMTIgMnYxIiAvPgogIDxwYXRoIGQ9Ik0xMiA4aDgiIC8+CiAgPHBhdGggZD0iTTEyIDlhNC4xNyA0LjE3IDAgMDEtMyA0IiAvPgogIDxwYXRoIGQ9Ik0xNiA4VjVhMiAyIDAgMDEyLTIiIC8+CiAgPHBhdGggZD0iTTYgMThhNCA0IDAgMDEtMi03LjQ2NSIgLz4KICA8cGF0aCBkPSJNNi4wMDQgNS4xMjVhNCA0IDAgMDAtMi41MjYgNS43NyIgLz4KICA8cGF0aCBkPSJNNi4yOTQgNi4yOTRBMyAzIDAgMTExMiA1djEzYTQgNCAwIDExLTcuOTY3LS41MTgiIC8+CiAgPGNpcmNsZSBjeD0iMTYiIGN5PSIxMyIgcj0iMC41IiBmaWxsPSJjdXJyZW50Q29sb3IiIC8+CiAgPGNpcmNsZSBjeD0iMTgiIGN5PSIzIiByPSIwLjUiIGZpbGw9ImN1cnJlbnRDb2xvciIgLz4KICA8Y2lyY2xlIGN4PSIyMCIgY3k9IjIxIiByPSIwLjUiIGZpbGw9ImN1cnJlbnRDb2xvciIgLz4KICA8Y2lyY2xlIGN4PSIyMCIgY3k9IjgiIHI9IjAuNSIgZmlsbD0iY3VycmVudENvbG9yIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/brain-circuit
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BrainCircuit = createLucideIcon(__iconData);

export default BrainCircuit;
