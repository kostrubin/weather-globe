import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'brush-cleaning',
  size: 24,
  node: [
    ['path', { d: 'm16 22-1-4', key: '1ow2iv' }],
    [
      'path',
      {
        d: 'M19 14a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2h-3a1 1 0 0 1-1-1V4a2 2 0 0 0-4 0v5a1 1 0 0 1-1 1H6a2 2 0 0 0-2 2v1a1 1 0 0 0 1 1',
        key: '11gii7',
      },
    ],
    ['path', { d: 'M19 14H5l-1.973 6.767A1 1 0 0 0 4 22h16a1 1 0 0 0 .973-1.233z', key: 'bju7h4' }],
    ['path', { d: 'm8 22 1-4', key: 's3unb' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BrushCleaning
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTYgMjItMS00IiAvPgogIDxwYXRoIGQ9Ik0xOSAxNGExIDEgMCAwIDAgMS0xdi0xYTIgMiAwIDAgMC0yLTJoLTNhMSAxIDAgMCAxLTEtMVY0YTIgMiAwIDAgMC00IDB2NWExIDEgMCAwIDEtMSAxSDZhMiAyIDAgMCAwLTIgMnYxYTEgMSAwIDAgMCAxIDEiIC8+CiAgPHBhdGggZD0iTTE5IDE0SDVsLTEuOTczIDYuNzY3QTEgMSAwIDAgMCA0IDIyaDE2YTEgMSAwIDAgMCAuOTczLTEuMjMzeiIgLz4KICA8cGF0aCBkPSJtOCAyMiAxLTQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/brush-cleaning
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BrushCleaning = createLucideIcon(__iconData);

export default BrushCleaning;
