import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chess-queen',
  size: 24,
  node: [
    ['path', { d: 'm10.68 5.499-.996 4.982a.65.65 0 01-1.131.295L5.885 7.663', key: '1qgnha' }],
    ['path', { d: 'm13.32 5.5.995 4.98a.65.65 0 001.131.296l2.668-3.113', key: '1tybta' }],
    ['path', { d: 'M20.428 8.952 17.5 18', key: 'ppcm61' }],
    [
      'path',
      { d: 'M4 20a2 2 0 012-2h12a2 2 0 012 2v1a1 1 0 01-1 1H5a1 1 0 01-1-1z', key: '1vltu5' },
    ],
    ['path', { d: 'M6.5 18 3.571 8.952', key: '1cx6vq' }],
    ['circle', { cx: '12', cy: '4', r: '2', key: 'muu5ef' }],
    ['circle', { cx: '20', cy: '7', r: '2', key: '9w7p1x' }],
    ['circle', { cx: '4', cy: '7', r: '2', key: '1d9wy8' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChessQueen
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTAuNjggNS40OTktLjk5NiA0Ljk4MmEuNjUuNjUgMCAwMS0xLjEzMS4yOTVMNS44ODUgNy42NjMiIC8+CiAgPHBhdGggZD0ibTEzLjMyIDUuNS45OTUgNC45OGEuNjUuNjUgMCAwMDEuMTMxLjI5NmwyLjY2OC0zLjExMyIgLz4KICA8cGF0aCBkPSJNMjAuNDI4IDguOTUyIDE3LjUgMTgiIC8+CiAgPHBhdGggZD0iTTQgMjBhMiAyIDAgMDEyLTJoMTJhMiAyIDAgMDEyIDJ2MWExIDEgMCAwMS0xIDFINWExIDEgMCAwMS0xLTF6IiAvPgogIDxwYXRoIGQ9Ik02LjUgMTggMy41NzEgOC45NTIiIC8+CiAgPGNpcmNsZSBjeD0iMTIiIGN5PSI0IiByPSIyIiAvPgogIDxjaXJjbGUgY3g9IjIwIiBjeT0iNyIgcj0iMiIgLz4KICA8Y2lyY2xlIGN4PSI0IiBjeT0iNyIgcj0iMiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/chess-queen
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChessQueen = createLucideIcon(__iconData);

export default ChessQueen;
