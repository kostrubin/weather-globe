import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'chart-no-axes-gantt',
  size: 24,
  node: [
    ['path', { d: 'M6 5h12', key: 'fvfigv' }],
    ['path', { d: 'M4 12h10', key: 'oujl3d' }],
    ['path', { d: 'M12 19h8', key: 'baeox8' }],
  ],
  aliases: ['gantt-chart'],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name ChartNoAxesGantt
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNiA1aDEyIiAvPgogIDxwYXRoIGQ9Ik00IDEyaDEwIiAvPgogIDxwYXRoIGQ9Ik0xMiAxOWg4IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/chart-no-axes-gantt
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const ChartNoAxesGantt = createLucideIcon(__iconData);

export default ChartNoAxesGantt;
