import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bone-fracture',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M14 4.5a1 1 0 0 1 5 0 .5.5 0 0 0 .5.5 1 1 0 0 1 0 5c-.81 0-1.8-.7-2.5 0l-1.958 1.957a.15.15 0 0 1-.252-.072l-.493-2.07a.15.15 0 0 0-.111-.112l-2.072-.494a.15.15 0 0 1-.072-.252L14 7c.7-.7 0-1.69 0-2.5',
        key: '1c7o5b',
      },
    ],
    ['path', { d: 'm16 20-1-2', key: '5348lt' }],
    ['path', { d: 'm20 16-2-1', key: '2c7pv5' }],
    ['path', { d: 'm4 8 2 1', key: 'rpj1x4' }],
    ['path', { d: 'm8 4 1 2', key: '1r4zbp' }],
    [
      'path',
      {
        d: 'M9.698 14.19a.15.15 0 0 0 .112.112l2.074.489a.15.15 0 0 1 .072.252L10 17c-.7.7 0 1.69 0 2.5a1 1 0 0 1-5 0 .495.495 0 0 0-.5-.5 1 1 0 0 1 0-5c.81 0 1.8.7 2.5 0l1.956-1.957a.15.15 0 0 1 .252.072z',
        key: '3u61yx',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BoneFracture
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQgNC41YTEgMSAwIDAgMSA1IDAgLjUuNSAwIDAgMCAuNS41IDEgMSAwIDAgMSAwIDVjLS44MSAwLTEuOC0uNy0yLjUgMGwtMS45NTggMS45NTdhLjE1LjE1IDAgMCAxLS4yNTItLjA3MmwtLjQ5My0yLjA3YS4xNS4xNSAwIDAgMC0uMTExLS4xMTJsLTIuMDcyLS40OTRhLjE1LjE1IDAgMCAxLS4wNzItLjI1MkwxNCA3Yy43LS43IDAtMS42OSAwLTIuNSIgLz4KICA8cGF0aCBkPSJtMTYgMjAtMS0yIiAvPgogIDxwYXRoIGQ9Im0yMCAxNi0yLTEiIC8+CiAgPHBhdGggZD0ibTQgOCAyIDEiIC8+CiAgPHBhdGggZD0ibTggNCAxIDIiIC8+CiAgPHBhdGggZD0iTTkuNjk4IDE0LjE5YS4xNS4xNSAwIDAgMCAuMTEyLjExMmwyLjA3NC40ODlhLjE1LjE1IDAgMCAxIC4wNzIuMjUyTDEwIDE3Yy0uNy43IDAgMS42OSAwIDIuNWExIDEgMCAwIDEtNSAwIC40OTUuNDk1IDAgMCAwLS41LS41IDEgMSAwIDAgMSAwLTVjLjgxIDAgMS44LjcgMi41IDBsMS45NTYtMS45NTdhLjE1LjE1IDAgMCAxIC4yNTIuMDcyeiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/bone-fracture
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BoneFracture = createLucideIcon(__iconData);

export default BoneFracture;
