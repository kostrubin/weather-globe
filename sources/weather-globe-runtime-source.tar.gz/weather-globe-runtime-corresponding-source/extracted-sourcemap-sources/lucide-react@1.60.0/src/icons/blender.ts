import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'blender',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M8 14a2 2 0 0 0-1.963 1.615l-1.018 5.193A1 1 0 0 0 6 22h12a1 1 0 0 0 .981-1.192l-1.018-5.193A2 2 0 0 0 16 14z',
        key: '11zxmj',
      },
    ],
    ['path', { d: 'm17 2-1 12', key: 'nxm2fw' }],
    ['path', { d: 'M8.006 14 7 2', key: '13bxiv' }],
    ['path', { d: 'M7.565 8.787A5 5 0 0 0 12 8a5 5 0 0 1 4.56-.75', key: '1s61ad' }],
    ['path', { d: 'M19 2H5a2 2 0 0 0-2 2v5a2 2 0 0 0 .688 1.5', key: 'gel3rg' }],
    ['path', { d: 'M12 18h.01', key: 'mhygvu' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Blender
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNOCAxNGEyIDIgMCAwIDAtMS45NjMgMS42MTVsLTEuMDE4IDUuMTkzQTEgMSAwIDAgMCA2IDIyaDEyYTEgMSAwIDAgMCAuOTgxLTEuMTkybC0xLjAxOC01LjE5M0EyIDIgMCAwIDAgMTYgMTR6IiAvPgogIDxwYXRoIGQ9Im0xNyAyLTEgMTIiIC8+CiAgPHBhdGggZD0iTTguMDA2IDE0IDcgMiIgLz4KICA8cGF0aCBkPSJNNy41NjUgOC43ODdBNSA1IDAgMCAwIDEyIDhhNSA1IDAgMCAxIDQuNTYtLjc1IiAvPgogIDxwYXRoIGQ9Ik0xOSAySDVhMiAyIDAgMCAwLTIgMnY1YTIgMiAwIDAgMCAuNjg4IDEuNSIgLz4KICA8cGF0aCBkPSJNMTIgMThoLjAxIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/blender
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Blender = createLucideIcon(__iconData);

export default Blender;
