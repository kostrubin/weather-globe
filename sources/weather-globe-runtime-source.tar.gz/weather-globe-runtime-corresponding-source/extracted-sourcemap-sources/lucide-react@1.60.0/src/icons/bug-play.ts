import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bug-play',
  size: 24,
  node: [
    ['path', { d: 'M10 19.655A6 6 0 0 1 6 14v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 3.97', key: '1gnv52' }],
    [
      'path',
      {
        d: 'M14 15.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z',
        key: '1weqy9',
      },
    ],
    ['path', { d: 'M14.12 3.88 16 2', key: 'qol33r' }],
    ['path', { d: 'M21 5a4 4 0 0 1-3.55 3.97', key: '5cxbf6' }],
    ['path', { d: 'M3 21a4 4 0 0 1 3.81-4', key: '1fjd4g' }],
    ['path', { d: 'M3 5a4 4 0 0 0 3.55 3.97', key: '1d7oge' }],
    ['path', { d: 'M6 13H2', key: '82j7cp' }],
    ['path', { d: 'm8 2 1.88 1.88', key: 'fmnt4t' }],
    ['path', { d: 'M9 7.13V6a3 3 0 1 1 6 0v1.13', key: '1vgav8' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BugPlay
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgMTkuNjU1QTYgNiAwIDAgMSA2IDE0di0zYTQgNCAwIDAgMSA0LTRoNGE0IDQgMCAwIDEgNCAzLjk3IiAvPgogIDxwYXRoIGQ9Ik0xNCAxNS4wMDNhMSAxIDAgMCAxIDEuNTE3LS44NTlsNC45OTcgMi45OTdhMSAxIDAgMCAxIDAgMS43MThsLTQuOTk3IDIuOTk3YTEgMSAwIDAgMS0xLjUxNy0uODZ6IiAvPgogIDxwYXRoIGQ9Ik0xNC4xMiAzLjg4IDE2IDIiIC8+CiAgPHBhdGggZD0iTTIxIDVhNCA0IDAgMCAxLTMuNTUgMy45NyIgLz4KICA8cGF0aCBkPSJNMyAyMWE0IDQgMCAwIDEgMy44MS00IiAvPgogIDxwYXRoIGQ9Ik0zIDVhNCA0IDAgMCAwIDMuNTUgMy45NyIgLz4KICA8cGF0aCBkPSJNNiAxM0gyIiAvPgogIDxwYXRoIGQ9Im04IDIgMS44OCAxLjg4IiAvPgogIDxwYXRoIGQ9Ik05IDcuMTNWNmEzIDMgMCAxIDEgNiAwdjEuMTMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bug-play
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BugPlay = createLucideIcon(__iconData);

export default BugPlay;
