import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'ad',
  size: 24,
  node: [
    ['path', { d: 'M10 13H6', key: '18d9xh' }],
    ['path', { d: 'M10 15v-4a2 2 0 0 0-4 0v4', key: 'ss28p3' }],
    [
      'path',
      {
        d: 'M14 14.5a.5.5 0 0 0 .5.5h1a2.5 2.5 0 0 0 2.5-2.5v-1A2.5 2.5 0 0 0 15.5 9h-1a.5.5 0 0 0-.5.5z',
        key: 'b3f847',
      },
    ],
    ['rect', { x: '2', y: '5', width: '20', height: '14', rx: '2', key: 'qneu4z' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Ad
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgMTNINiIgLz4KICA8cGF0aCBkPSJNMTAgMTV2LTRhMiAyIDAgMCAwLTQgMHY0IiAvPgogIDxwYXRoIGQ9Ik0xNCAxNC41YS41LjUgMCAwIDAgLjUuNWgxYTIuNSAyLjUgMCAwIDAgMi41LTIuNXYtMUEyLjUgMi41IDAgMCAwIDE1LjUgOWgtMWEuNS41IDAgMCAwLS41LjV6IiAvPgogIDxyZWN0IHg9IjIiIHk9IjUiIHdpZHRoPSIyMCIgaGVpZ2h0PSIxNCIgcng9IjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/ad
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Ad = createLucideIcon(__iconData);

export default Ad;
