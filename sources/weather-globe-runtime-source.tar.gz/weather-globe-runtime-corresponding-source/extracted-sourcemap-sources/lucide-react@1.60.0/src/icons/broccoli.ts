import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'broccoli',
  size: 24,
  node: [
    ['path', { d: 'M10 13a3 3 0 01-2.121-5.121', key: '1g9r2w' }],
    [
      'path',
      {
        d: 'M15.606 14.204c-3.5 1.5-5.899 4.503-8.899 7.503A1 1 0 016 22c-2 0-4-2-4-4a1 1 0 01.293-.707c1.911-1.911 3.823-3.578 5.347-5.441',
        key: '1ansp5',
      },
    ],
    ['path', { d: 'M16.573 14.737A4 4 0 0114 11', key: 'icunya' }],
    [
      'path',
      {
        d: 'M7.14 10.907a4 4 0 112.756-7.43A4 4 0 0116.7 4.48a2 2 0 012.82 2.82 4 4 0 011.002 6.805 4 4 0 11-7.51 1.59',
        key: 'cbikky',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Broccoli
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgMTNhMyAzIDAgMDEtMi4xMjEtNS4xMjEiIC8+CiAgPHBhdGggZD0iTTE1LjYwNiAxNC4yMDRjLTMuNSAxLjUtNS44OTkgNC41MDMtOC44OTkgNy41MDNBMSAxIDAgMDE2IDIyYy0yIDAtNC0yLTQtNGExIDEgMCAwMS4yOTMtLjcwN2MxLjkxMS0xLjkxMSAzLjgyMy0zLjU3OCA1LjM0Ny01LjQ0MSIgLz4KICA8cGF0aCBkPSJNMTYuNTczIDE0LjczN0E0IDQgMCAwMTE0IDExIiAvPgogIDxwYXRoIGQ9Ik03LjE0IDEwLjkwN2E0IDQgMCAxMTIuNzU2LTcuNDNBNCA0IDAgMDExNi43IDQuNDhhMiAyIDAgMDEyLjgyIDIuODIgNCA0IDAgMDExLjAwMiA2LjgwNSA0IDQgMCAxMS03LjUxIDEuNTkiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/broccoli
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Broccoli = createLucideIcon(__iconData);

export default Broccoli;
