import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'circle-dashed-check',
  size: 24,
  node: [
    ['path', { d: 'M10.1 2.182a10 10 0 013.8 0', key: 'upsxbf' }],
    ['path', { d: 'M13.9 21.818a10 10 0 01-3.8 0', key: 'ms125y' }],
    ['path', { d: 'm16 9-5.5 5.5L8 12', key: 'xofnsj' }],
    ['path', { d: 'M17.609 3.721a10 10 0 012.69 2.7', key: 'iyn141' }],
    ['path', { d: 'M2.182 13.9a10 10 0 010-3.8', key: '68e3e5' }],
    ['path', { d: 'M20.279 17.609a10 10 0 01-2.7 2.69', key: 'wpakmt' }],
    ['path', { d: 'M21.818 10.1a10 10 0 010 3.8', key: 'w6g6ls' }],
    ['path', { d: 'M3.721 6.391a10 10 0 012.7-2.69', key: 'sn8908' }],
    ['path', { d: 'M6.391 20.279a10 10 0 01-2.69-2.7', key: '11rjuk' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name CircleDashedCheck
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAuMSAyLjE4MmExMCAxMCAwIDAxMy44IDAiIC8+CiAgPHBhdGggZD0iTTEzLjkgMjEuODE4YTEwIDEwIDAgMDEtMy44IDAiIC8+CiAgPHBhdGggZD0ibTE2IDktNS41IDUuNUw4IDEyIiAvPgogIDxwYXRoIGQ9Ik0xNy42MDkgMy43MjFhMTAgMTAgMCAwMTIuNjkgMi43IiAvPgogIDxwYXRoIGQ9Ik0yLjE4MiAxMy45YTEwIDEwIDAgMDEwLTMuOCIgLz4KICA8cGF0aCBkPSJNMjAuMjc5IDE3LjYwOWExMCAxMCAwIDAxLTIuNyAyLjY5IiAvPgogIDxwYXRoIGQ9Ik0yMS44MTggMTAuMWExMCAxMCAwIDAxMCAzLjgiIC8+CiAgPHBhdGggZD0iTTMuNzIxIDYuMzkxYTEwIDEwIDAgMDEyLjctMi42OSIgLz4KICA8cGF0aCBkPSJNNi4zOTEgMjAuMjc5YTEwIDEwIDAgMDEtMi42OS0yLjciIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/circle-dashed-check
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const CircleDashedCheck = createLucideIcon(__iconData);

export default CircleDashedCheck;
