import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'carton',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M13 22V10a2 2 0 01.539-1.367L16 6H8L5.539 8.633A2 2 0 005 10v10a2 2 0 002 2h10a2 2 0 002-2V10a2 2 0 00-.539-1.367L16 6V3a1 1 0 00-1-1H9a1 1 0 00-1 1v3',
        key: '9jv8ej',
      },
    ],
    ['path', { d: 'M5 10h8', key: 'gs3i43' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Carton
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTMgMjJWMTBhMiAyIDAgMDEuNTM5LTEuMzY3TDE2IDZIOEw1LjUzOSA4LjYzM0EyIDIgMCAwMDUgMTB2MTBhMiAyIDAgMDAyIDJoMTBhMiAyIDAgMDAyLTJWMTBhMiAyIDAgMDAtLjUzOS0xLjM2N0wxNiA2VjNhMSAxIDAgMDAtMS0xSDlhMSAxIDAgMDAtMSAxdjMiIC8+CiAgPHBhdGggZD0iTTUgMTBoOCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/carton
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Carton = createLucideIcon(__iconData);

export default Carton;
