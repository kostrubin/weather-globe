import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'briefcase-plus',
  size: 24,
  node: [
    ['path', { d: 'M13.354 20H4a2 2 0 01-2-2V8a2 2 0 012-2h16a2 2 0 012 2v3.354', key: '59v5n6' }],
    ['path', { d: 'M16 11.354V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v16', key: '13yhyp' }],
    ['path', { d: 'M16 17h6', key: '1ook5g' }],
    ['path', { d: 'M19 14v6', key: '1ckrd5' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BriefcasePlus
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTMuMzU0IDIwSDRhMiAyIDAgMDEtMi0yVjhhMiAyIDAgMDEyLTJoMTZhMiAyIDAgMDEyIDJ2My4zNTQiIC8+CiAgPHBhdGggZD0iTTE2IDExLjM1NFY0YTIgMiAwIDAwLTItMmgtNGEyIDIgMCAwMC0yIDJ2MTYiIC8+CiAgPHBhdGggZD0iTTE2IDE3aDYiIC8+CiAgPHBhdGggZD0iTTE5IDE0djYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/briefcase-plus
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BriefcasePlus = createLucideIcon(__iconData);

export default BriefcasePlus;
