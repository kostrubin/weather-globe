import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'church',
  size: 24,
  node: [
    ['path', { d: 'M10 9h4', key: 'u4k05v' }],
    ['path', { d: 'M12 7v5', key: 'ma6bk' }],
    ['path', { d: 'M14 21v-3a2 2 0 0 0-4 0v3', key: '1rgiei' }],
    [
      'path',
      {
        d: 'm18 9 3.52 2.147a1 1 0 0 1 .48.854V19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6.999a1 1 0 0 1 .48-.854L6 9',
        key: 'flvdwo',
      },
    ],
    [
      'path',
      {
        d: 'M6 21V7a1 1 0 0 1 .376-.782l5-3.999a1 1 0 0 1 1.249.001l5 4A1 1 0 0 1 18 7v14',
        key: 'a5i0n2',
      },
    ],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Church
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTAgOWg0IiAvPgogIDxwYXRoIGQ9Ik0xMiA3djUiIC8+CiAgPHBhdGggZD0iTTE0IDIxdi0zYTIgMiAwIDAgMC00IDB2MyIgLz4KICA8cGF0aCBkPSJtMTggOSAzLjUyIDIuMTQ3YTEgMSAwIDAgMSAuNDguODU0VjE5YTIgMiAwIDAgMS0yIDJINGEyIDIgMCAwIDEtMi0ydi02Ljk5OWExIDEgMCAwIDEgLjQ4LS44NTRMNiA5IiAvPgogIDxwYXRoIGQ9Ik02IDIxVjdhMSAxIDAgMCAxIC4zNzYtLjc4Mmw1LTMuOTk5YTEgMSAwIDAgMSAxLjI0OS4wMDFsNSA0QTEgMSAwIDAgMSAxOCA3djE0IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/church
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Church = createLucideIcon(__iconData);

export default Church;
