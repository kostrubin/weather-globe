import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'book-search',
  size: 24,
  node: [
    ['path', { d: 'M11 22H5.5a1 1 0 0 1 0-5h4.501', key: 'mcbepb' }],
    ['path', { d: 'm21 22-1.879-1.878', key: '12q7x1' }],
    ['path', { d: 'M3 19.5v-15A2.5 2.5 0 0 1 5.5 2H18a1 1 0 0 1 1 1v8', key: 'olfd5n' }],
    ['circle', { cx: '17', cy: '18', r: '3', key: '82mm0e' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name BookSearch
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTEgMjJINS41YTEgMSAwIDAgMSAwLTVoNC41MDEiIC8+CiAgPHBhdGggZD0ibTIxIDIyLTEuODc5LTEuODc4IiAvPgogIDxwYXRoIGQ9Ik0zIDE5LjV2LTE1QTIuNSAyLjUgMCAwIDEgNS41IDJIMThhMSAxIDAgMCAxIDEgMXY4IiAvPgogIDxjaXJjbGUgY3g9IjE3IiBjeT0iMTgiIHI9IjMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/book-search
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const BookSearch = createLucideIcon(__iconData);

export default BookSearch;
