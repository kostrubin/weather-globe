import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'anchor',
  size: 24,
  node: [
    ['path', { d: 'M12 6v16', key: 'nqf5sj' }],
    ['path', { d: 'm19 13 2-1a9 9 0 0 1-18 0l2 1', key: 'y7qv08' }],
    ['path', { d: 'M9 11h6', key: '1fldmi' }],
    ['circle', { cx: '12', cy: '4', r: '2', key: 'muu5ef' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Anchor
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgNnYxNiIgLz4KICA8cGF0aCBkPSJtMTkgMTMgMi0xYTkgOSAwIDAgMS0xOCAwbDIgMSIgLz4KICA8cGF0aCBkPSJNOSAxMWg2IiAvPgogIDxjaXJjbGUgY3g9IjEyIiBjeT0iNCIgcj0iMiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/anchor
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Anchor = createLucideIcon(__iconData);

export default Anchor;
