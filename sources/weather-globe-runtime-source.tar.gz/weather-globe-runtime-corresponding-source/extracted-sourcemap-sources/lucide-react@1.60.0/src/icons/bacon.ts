import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bacon',
  size: 24,
  node: [
    [
      'path',
      {
        d: 'M2.795 16.804c-.789-.79-1.09-2.018-.442-2.928 1.933-2.713 4.414-1.05 6.145-5.378 1.868-4.67 4.608-2.366 6.592-6.107.218-.412.78-.53 1.11-.2l5.005 5.005c.789.79 1.09 2.018.442 2.928-1.933 2.713-4.414 1.05-6.145 5.378-1.868 4.67-4.608 2.366-6.591 6.107-.22.412-.78.53-1.11.2z',
        key: '15j3n2',
      },
    ],
    ['path', { d: 'M4.5 18.5c2-5 5-2 7-7s5-2 7-7', key: '191iws' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Bacon
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMi43OTUgMTYuODA0Yy0uNzg5LS43OS0xLjA5LTIuMDE4LS40NDItMi45MjggMS45MzMtMi43MTMgNC40MTQtMS4wNSA2LjE0NS01LjM3OCAxLjg2OC00LjY3IDQuNjA4LTIuMzY2IDYuNTkyLTYuMTA3LjIxOC0uNDEyLjc4LS41MyAxLjExLS4ybDUuMDA1IDUuMDA1Yy43ODkuNzkgMS4wOSAyLjAxOC40NDIgMi45MjgtMS45MzMgMi43MTMtNC40MTQgMS4wNS02LjE0NSA1LjM3OC0xLjg2OCA0LjY3LTQuNjA4IDIuMzY2LTYuNTkxIDYuMTA3LS4yMi40MTItLjc4LjUzLTEuMTEuMnoiIC8+CiAgPHBhdGggZD0iTTQuNSAxOC41YzItNSA1LTIgNy03czUtMiA3LTciIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bacon
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Bacon = createLucideIcon(__iconData);

export default Bacon;
