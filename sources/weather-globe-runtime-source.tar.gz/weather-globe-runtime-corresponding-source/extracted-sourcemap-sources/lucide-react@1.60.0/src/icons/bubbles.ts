import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'bubbles',
  size: 24,
  node: [
    ['path', { d: 'M7.001 15.085A1.5 1.5 0 0 1 9 16.5', key: 'y44lvh' }],
    ['circle', { cx: '18.5', cy: '8.5', r: '3.5', key: '1wadoa' }],
    ['circle', { cx: '7.5', cy: '16.5', r: '5.5', key: '6mdt3g' }],
    ['circle', { cx: '7.5', cy: '4.5', r: '2.5', key: '637s54' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Bubbles
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNy4wMDEgMTUuMDg1QTEuNSAxLjUgMCAwIDEgOSAxNi41IiAvPgogIDxjaXJjbGUgY3g9IjE4LjUiIGN5PSI4LjUiIHI9IjMuNSIgLz4KICA8Y2lyY2xlIGN4PSI3LjUiIGN5PSIxNi41IiByPSI1LjUiIC8+CiAgPGNpcmNsZSBjeD0iNy41IiBjeT0iNC41IiByPSIyLjUiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bubbles
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Bubbles = createLucideIcon(__iconData);

export default Bubbles;
