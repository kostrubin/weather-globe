import createLucideIcon from '../createLucideIcon';
import type { LucideIconNode, LucideIconData } from '../types';

export const __iconData: LucideIconData = {
  name: 'can',
  size: 24,
  node: [
    ['path', { d: 'M21 10.5a9 2.5 0 01-18 0v8a9 2.5 0 0018 0z', key: '9pzxzq' }],
    ['path', { d: 'M21 10.5A9 2.5 25.32 004.59 3.47 9 2.5 25.32 0021 10.5', key: '9bp7vi' }],
    ['path', { d: 'M3 10.5a9 2.5 0 016.527-2.405', key: '13emm5' }],
    ['path', { d: 'M9 16.858a31 31 0 006 0', key: '1nnpid' }],
  ],
};

/**
 * @deprecated Access `__iconData` instead.
 */
export const __iconNode: LucideIconNode[] = __iconData.node;

/**
 * @component @name Can
 * @description Lucide SVG icon component, renders SVG Element with children.
 *
 * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEgMTAuNWE5IDIuNSAwIDAxLTE4IDB2OGE5IDIuNSAwIDAwMTggMHoiIC8+CiAgPHBhdGggZD0iTTIxIDEwLjVBOSAyLjUgMjUuMzIgMDA0LjU5IDMuNDcgOSAyLjUgMjUuMzIgMDAyMSAxMC41IiAvPgogIDxwYXRoIGQ9Ik0zIDEwLjVhOSAyLjUgMCAwMTYuNTI3LTIuNDA1IiAvPgogIDxwYXRoIGQ9Ik05IDE2Ljg1OGEzMSAzMSAwIDAwNiAwIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/can
 * @see https://lucide.dev/guide/packages/lucide-react - Documentation
 *
 * @param {Object} props - Lucide icons props and any valid SVG attribute
 * @returns {JSX.Element} JSX Element
 *
 */
const Can = createLucideIcon(__iconData);

export default Can;
